/*
 * $Author: lgh $
 * $Header: /data/cvsroot/plportest/src/socket.c,v 1.7.2.1 2007/11/26 08:45:08 lgh Exp $
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <errno.h>
/* fcntl */
#include <unistd.h>
#include <fcntl.h>
#ifdef PLPROPER
#include <proper/prop.h>
#endif

#include <pcap.h>
#include <string.h>

#include "errfun.h"
#include "socket.h"


/* assume always return success */
int 
set_sock_rcvbuf(int fd, int buflen)
{
    int val;
    socklen_t len;

    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &buflen, sizeof(int));

    len = sizeof(int);
    getsockopt(fd, SOL_SOCKET, SO_RCVBUF, &val, &len);
#ifdef DEBUG
    dbg_msg("socket %d so_rcvbuf %u\n", fd, val);
#endif

    return 0;
}

int 
set_sock_sndbuf(int fd, int buflen)
{
    int val;
    socklen_t len;

    if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &buflen, sizeof(int)) == -1) {
	err_ret("[%s] setsockopt", __func__);
	return -1;
    }

    len = sizeof(int);
    /* The buffer size returned from kernel is larger than you expected.
     * see: "[Raphael Manfredi] setsockopt(SOL_SOCKET, SO_SNDBUF) broken on 2.4.18?" 
     * http://www.ussg.iu.edu/hypermail/linux/kernel/0202.3/0324.html
     */
    getsockopt(fd, SOL_SOCKET, SO_SNDBUF, &val, &len);

    return 0;
    
}

int 
set_sock_nonblock(int fd)
{
    int val;

    val = fcntl(fd, F_GETFL, 0);
    if (fcntl(fd, F_SETFL, val | O_NONBLOCK) == -1) {
	err_ret("[%s] fail to set %d nonblock", __func__, fd);
	close(fd);
	return -1;
    }

    return 0;
}

int
set_sock_block(int fd)
{
    int val;

    val = fcntl(fd, F_GETFL, 0);
    return(fcntl(fd, F_SETFL, val & ~O_NONBLOCK));
}

/*
 * portable get_local_ip.
 *
 * getifaddrs() is provided by GNU libc.
 *
 */
int
get_local_ip(char ip_str[], u_int32_t *ip, u_int32_t *netmask, const char *iface)
{
    struct ifaddrs *pifa_head, *pifa;
    struct sockaddr_in *sin;

    if (getifaddrs(&pifa_head) == 1) {
	err_ret("[get_local_ip] getifaddr failed");
	return -1;
    }

    pifa = pifa_head;
    while (pifa) {
        if (!pifa->ifa_addr) {
        	pifa = pifa->ifa_next;
            continue;
        }
#ifdef DEBUG
	dbg_msg("ifname %s,%d %s,%d\n", pifa->ifa_name, pifa->ifa_addr->sa_family, iface, AF_INET);
#endif
	if (strncmp(iface, pifa->ifa_name, 10) == 0
	    	    && pifa->ifa_addr->sa_family == AF_INET) {
	    sin = (struct sockaddr_in *)pifa->ifa_addr;
	    *ip      = sin->sin_addr.s_addr;
	    strncpy(ip_str, inet_ntoa(sin->sin_addr), 20);
	    sin = (struct sockaddr_in *)pifa->ifa_netmask;
	    *netmask = sin->sin_addr.s_addr;
#ifdef DEBUG
	    dbg_msg("netmask %s\n", inet_ntoa(*(struct in_addr *)netmask));
#endif
	    freeifaddrs(pifa_head);
	    return 0;
	}
	pifa = pifa->ifa_next;
    }
    return -1;
}

#if 0
#include<net/if.h>
#ifdef linux
#include<linux/sockios.h>
#else
#include<sys/sockio.h>
#endif
int
get_local_ip(char local_ip_str[], const char *iface)
{
    struct ifconf ifc;
    struct ifreq *ifr, ifrcopy;
    struct sockaddr_in *sin;
    char ifcbuf[IFC_BUFLEN], *p, *a;
    int sockfd;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
	err_sys("[get_local_ip]:socket");
    }

    ifc.ifc_len = IFC_BUFLEN;
    ifc.ifc_buf = ifcbuf;
    if (ioctl(sockfd, SIOCGIFCONF, &ifc) < 0) {
	err_sys("[%s]:ioctl", __func__);
    }
#ifdef DEBUG
    dbg_msg("sizeof(ifreq) = %d\n", sizeof(struct ifreq));
#endif

    for (p = ifcbuf; p < ifcbuf + ifc.ifc_len;p = p + sizeof(struct ifreq)) {
	ifr = (struct ifreq *)p;
#ifdef DEBUG
	dbg_msg("ifname %s,%d %s,%d\n", ifr->ifr_name, ifr->ifr_addr.sa_family, iface, AF_INET);
#endif
	if (strncmp(iface, ifr->ifr_name, IFNAMSIZ) == 0
	    	    && ifr->ifr_addr.sa_family == AF_INET) {
	    /* this piece of code doesn't work on freebsd. */
	    sin = (struct sockaddr_in *)&ifr->ifr_addr;
	    local_ip = sin->sin_addr.s_addr;
	    a = inet_ntoa(sin->sin_addr);
	    strncpy(local_ip_str, a, 20);
	    ifrcopy = *ifr;
	    if (ioctl(sockfd, SIOCGIFNETMASK, &ifrcopy) < 0)
		err_sys("[%s]:ioctl SIOCGIFNETMASK", __func__);
	    sin = (struct sockaddr_in *)&ifrcopy.ifr_addr;
	    netmask = sin->sin_addr.s_addr;
#ifdef DEBUG
	    dbg_msg("netmask %s\n", inet_ntoa(*(struct in_addr *)&netmask));
#endif
	    close(sockfd);
	    return(1);
	}
    }
    close(sockfd);
    return(0);
}
#endif

pcap_t *
open_pcap(char *ifname, int snaplen, char *bpf_filter)
{
    pcap_t *pt;
    bpf_u_int32 localnet, netmask;
    char errbuf[PCAP_ERRBUF_SIZE];
    int pfsock, i;
    struct bpf_program bfprog;


    /* It's maybe better to use PF_PACKET mechanism to dump send and
       receive packets. may refer to Spring's scriptroute.  However,
       PF_PACKET may drop packet. raw socket also drop packets. seems
       that PF_PACKET drop less packets than raw packet */
    if ((pt = pcap_open_live(ifname, snaplen, 1, 0, errbuf)) == NULL)
	err_quit("[%s] %s", __func__, errbuf);
    if (pcap_lookupnet(ifname, &localnet, &netmask, errbuf) < 0) {
	localnet = 0;
	netmask  = 0;
    }
    if (bpf_filter) {
	if (pcap_compile(pt, &bfprog, bpf_filter, 0, netmask) == -1)
	    err_quit(pcap_geterr(pt));

	if (pcap_setfilter(pt, &bfprog) == -1)
	    err_quit(pcap_geterr(pt));
    }
    pfsock = pcap_fileno(pt);
    /* on PlanetLab, buffer size limit is 262142. */
    set_sock_rcvbuf(pfsock, 256000);
#ifdef DEBUG
    dbg_msg("pcap opened for interface %s\n", ifname);
#endif
    return pt;
}

int
open_rawsend()
{
    int sockfd;
    sockfd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sockfd < 0)
	err_sys("fail to open rawsend socket:");
#ifdef DEBUG
    dbg_msg("raw socket opened\n");
#endif
    return sockfd;
}

#ifdef PlanetLab
int
bind_port(u_int8_t protocol, u_int16_t sport_id)
{

    struct sockaddr_in sin;
    int sockfd;

    if ((sockfd = socket(PF_INET, SOCK_RAW, protocol)) < 0) {
	err_ret("[%s] open socket", __func__);
	return(-1);
    }
    bzero((char *)&sin, sizeof(sin));
    if (protocol != IPPROTO_ICMP)
	sin.sin_family = PF_INET;
    sin.sin_port = htons(sport_id);
    /* we don't need to bound for a ordinary linux box */
    if (protocol != IPPROTO_ICMP && sport_id < 1024) {
#ifdef PLPROPER
	if ((prop_bind_socket(sockfd, (struct sockaddr *)&sin, sizeof(sin))) < 0) {
	    err_ret("[%s] prop_bind (%d, %d) (%d)", __func__, protocol, sport_id, errno);
	    return(-1);
	}
#ifdef DEBUG
	else {
	    dbg_msg("[%s] prop_bind (%d, %d) ok\n", __func__, protocol, sport_id);
	}
#endif /* DEBUG */
#else
	err_msg("[%s] lack of previledge to bind (%d,%d), compile with proper",
		__func__, protocol, sport_id);
	return(-1);
#endif /* PLPROPER */
    } else {
	if ((bind(sockfd, (struct sockaddr *)&sin, sizeof(sin))) < 0) {
	    err_ret("[%s] bind (%d, %d)", __func__, protocol, sport_id);
	    return(-1);
	}
#ifdef DEBUG
	else {
	    dbg_msg("[%s] bind (%d, %d) ok\n", __func__, protocol, sport_id); 
	}
#endif
    }
    return 0;
}
#endif
