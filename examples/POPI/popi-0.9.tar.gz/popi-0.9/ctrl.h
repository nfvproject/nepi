#ifndef _CTRL_H_
#define _CTRL_H_

int open_control_channel(u_int32_t daddr, u_int16_t dport, u_int8_t ttl);
int send_control_cmd(int fd, char *cmdbuf);

#endif
