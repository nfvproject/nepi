#include<sys/types.h>
#include<unistd.h>
#include<syslog.h>
#include<signal.h>
#include<errno.h>
#include<stdio.h>
#include<stdarg.h>
#include<string.h>
#include<stdlib.h>
#include<sys/time.h>
#include<time.h>

#include"monfun.h"
#include"errfun.h"

int  daemonized = 0;
static FILE *logfp = NULL;

static void err_doit(int, int, const char *, va_list);

int
open_logfile(const char *filename)
{
    if ((logfp = fopen(filename, "a")) == NULL)
	return -1;

    return 0;
}

/* Non fatal related to a system call.
 * Print a msg and return */ 
void err_ret(const char *fmt,...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(1, LOG_INFO, fmt, ap);
    va_end(ap);
    return;
}

/* Fatal Error related to a system call.
 * log a msg, send msg to mon server, and terminate. */
void err_sys(const char *fmt,...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(1, LOG_ERR, fmt, ap);
    va_end(ap);
    exit(1);
}

/* Non fatal unrelated to a system call.
 * Print a msg and return */ 
void err_msg(const char *fmt,...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(0, LOG_INFO, fmt, ap);
    va_end(ap);
    return;
}

/* Fatal error unrelated to system call.
 * log the msg, sendto mon server and terminate. */
void err_quit(const char *fmt,...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(0, LOG_ERR, fmt, ap);
    va_end(ap);
    exit(1);
}

/* Debug msg.
 * Print the msg and return */
void dbg_msg(const char *fmt,...)
{
    va_list ap;
    
    va_start(ap, fmt);
    err_doit(0, LOG_DEBUG, fmt, ap);
    va_end(ap);
    return;
}


static void
err_doit(int errnoflag, int level, const char *fmt, va_list ap)
{
    int errno_save, n;
    static char buf[3000];
    struct timeval curtv;
    size_t sn;

    errno_save = errno;
    gettimeofday(&curtv, NULL);
    sn = strftime(buf, 20, "%b %d %T ", localtime((time_t *)&(curtv.tv_sec)));
    vsnprintf(buf + sn, sizeof(buf) - sn, fmt, ap);
    n = strlen(buf);
    if (errnoflag)
	snprintf(buf + n, sizeof(buf) - n - 1, ": %s", strerror(errno_save));
    if (level != LOG_DEBUG)
	strcat(buf, "\n");
    if (daemonized) {
	fprintf(logfp, buf);
	fflush(logfp);
    } else {
	fprintf(stderr, buf);
	fflush(stderr);
    }
    /* preserve errno */
    errno = errno_save;
    return;
}
