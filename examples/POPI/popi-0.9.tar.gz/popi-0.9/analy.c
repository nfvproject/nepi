/* Print POPI dump file */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pcap.h>
#include <assert.h>

#include "popi_common.h"
#include "errfun.h"
#include "utils.h"

/*
 *  The union cast uses a gcc extension to avoid aliasing problems
 *  (union is compatible to any of its members)
 *  This means this part of the code is -fstrict-aliasing safe now.
 */
union tcp_byte_hdr {
    struct tcphdr hdr;
    u_int8_t bytes[20];
};
#define tcp_flag_byte(tp) ( ((union tcp_byte_hdr *)(tp))->bytes [13])

enum {
    TCP_FLAG_CWR = 0x80,
    TCP_FLAG_ECE = 0x40,
    TCP_FLAG_URG = 0x20,
    TCP_FLAG_ACK = 0x10,
    TCP_FLAG_PSH = 0x08,
    TCP_FLAG_RST = 0x04,
    TCP_FLAG_SYN = 0x02,
    TCP_FLAG_FIN = 0x01
};

typedef struct {
    struct timeval tv;
    unsigned short len;
    unsigned char  type;     /* 1 for comment, 0 for dumped packet */
} __attribute__ ((packed)) dmphdr_t;

/* Packet decoder for dmp version 2,3 */
typedef struct {
    unsigned char  tos;
    unsigned short tot_len;
    unsigned short ipid;
    unsigned short frag_off;
    unsigned char  ttl;
    unsigned char  protocol;
    union {
	struct tcphdr tcp;
	struct udphdr udp;
	struct icmphdr icmp;
    };
    unsigned short round;
    unsigned char  ipkt;
} __attribute__ ((packed)) pdecode_t;


static char rev[REV_LEN]="$Revision: 1.8 $";
static int opt_verbose = 0;
static FILE *fp;
static u_int32_t dumplen;

unsigned char *dump_next(dmphdr_t *pdmphdr)
{
    static unsigned char item[4096];
    size_t n;

    n = fread(pdmphdr, sizeof(dmphdr_t), 1, fp);
    if (n < sizeof(dmphdr_t)) {
	if (feof(fp)) return NULL;
	if (ferror(fp)) err_sys("fread error");
    }
    pdmphdr->tv.tv_sec  = ntohl(pdmphdr->tv.tv_sec);
    pdmphdr->tv.tv_usec = ntohl(pdmphdr->tv.tv_usec);
    pdmphdr->len = ntohs(pdmphdr->len);
    n = fread(item, pdmphdr->len, 1, fp);
    if (n < pdmphdr->len) {
	if (feof(fp)) return NULL;
	if (ferror(fp)) err_sys("fread error");
    }
    return item;
}

int
main(int argc, char *argv[])
{
    char sipstr[20], dipstr[20];
    char popidrev[REV_LEN];
    unsigned char *item;
    dmphdr_t dmphdr;
    int c;
    u_int8_t dmp_major_ver, dmp_minor_ver;

    assert(sizeof(pdecode_t) == 32);
    while ((c = getopt(argc, argv, "v")) != EOF) {
	switch(c) {
	case 'v':
	    opt_verbose++;
	    break;
	default:
	    err_quit("no such option!");
	}
    }

    if ((fp = fopen(argv[optind], "r")) == NULL)
	err_sys("open %s", argv[1]);
    fread(&dmp_major_ver, 1, 1, fp);
    fread(&dmp_minor_ver, 1, 1, fp);
    if (dmp_major_ver != 3 && dmp_major_ver != 4)
	err_quit("unsupported popi dump version %d.%d", dmp_major_ver, dmp_minor_ver);
    fread(&dumplen, 2, 1, fp);
    fread(popidrev, REV_LEN, 1, fp);
    dumplen = ntohs(dumplen);
    if (opt_verbose)
	printf("dump ver %d.%d dumplen %d rev \"%s\"\n", 
	       dmp_major_ver, dmp_minor_ver,
	       dumplen, rev);

    /* read packets */
    while((item = dump_next(&dmphdr))) {
	/* comment */
	if (dmphdr.type) {
	    printf("# %u.%06u ", dmphdr.tv.tv_sec, dmphdr.tv.tv_usec);
	    item[dmphdr.len] = '\0';
	    printf("%s\n", item);
	    continue;
	}
	
	/* packet */
	if (dmp_major_ver == 4) {
	    struct iphdr *iph = (struct iphdr *)item;
	    struct udphdr *uh;
	    struct tcphdr *th;
	    struct icmphdr *icmph;
	    datamx_t *pd;
	    u_int16_t sport_id, dport_type;
	    int hlen;

	    printf("%u.%06u ", dmphdr.tv.tv_sec, dmphdr.tv.tv_usec);
	    strncpy(sipstr, GET_IPSTR(iph->saddr), 20);
	    strncpy(dipstr, GET_IPSTR(iph->daddr), 20);
	    printf("IP(saddr=%s,daddr=%s,tos=%d,len=%d,id=%u,ttl=%d,proto=%d)", 
		   sipstr, dipstr, iph->tos, ntohs(iph->tot_len), ntohs(iph->id),
		   iph->ttl, iph->protocol);
	    switch(iph->protocol) {
	    case IPPROTO_UDP:
		uh = (struct udphdr *)(iph + 1);
		sport_id   = uh->source;
		dport_type = uh->dest;
		printf("+UDP(sport=%d,dport=%d)", ntohs(uh->source), ntohs(uh->dest));
		hlen = 28;
		pd = (datamx_t *)(uh + 1);
		break;
	    case IPPROTO_TCP:
		th = (struct tcphdr *)(iph + 1);
		sport_id   = th->source;
		dport_type = th->dest;
		printf("+TCP(sport=%d,dport=%d,thflags=", ntohs(th->source), ntohs(th->dest));
		if (th->rst)
		    printf("r");
		if (th->syn)
		    printf("s");
		if (th->fin)
		    printf("f");
		if (th->ack)
		    printf("a");
		if (th->urg)
		    printf("u");
		if (th->psh)
		    printf("p");
		printf(",seq=%u,ack=%u)", ntohl(th->seq), ntohl(th->ack_seq));
		hlen = 20 + th->doff * 4;
		pd = (datamx_t *)((char *)th + th->doff * 4);
		break;
	    case IPPROTO_ICMP:
		icmph = (struct icmphdr *)(iph + 1);
		sport_id   = icmph->un.echo.id;
		dport_type = icmph->type;
		dport_type = htons(dport_type);
		printf("+ICMP(type=%u,code=%u,id=%u,seq=%u)",
		       icmph->type, icmph->code, ntohs(icmph->un.echo.id), 
		       ntohs(icmph->un.echo.sequence));
		/* icmp error packet */
		if (icmph->type == 11) {
		    iph = (struct iphdr *)(icmph + 1);
		    strncpy(sipstr, GET_IPSTR(iph->saddr), 20);
		    strncpy(dipstr, GET_IPSTR(iph->daddr), 20);
		    printf("+IP(saddr=%s,daddr=%s,tos=%d,len=%d,id=%u,ttl=%d,proto=%d)\n", 
			   sipstr, dipstr, iph->tos, ntohs(iph->tot_len), ntohs(iph->id), 
			   iph->ttl, iph->protocol);
		    continue;
		}
		hlen = 28;
		pd = (datamx_t *)(icmph + 1);
		break;
	    default:
		printf("%s > %s: prot %u!\n", sipstr, dipstr, iph->protocol);
		continue;
	    }

	    /* datamx_t */
	    if (hlen + POPIHDRLEN <= dmphdr.len) { 
		if (in_cksum((unsigned short *)pd, POPIHDRLEN)) {
		    printf("ck err!\n");
		    continue;
		}
		if (pd->ver == 4) {
		    if (opt_verbose)
			printf(" dL%u r%u i%u ver%u m%u %u.%u echo %u.%u", pd->hlen, ntohs(pd->round), pd->ipkt, pd->ver,
			       ntohs(pd->magic), ntohl(pd->tv_sec), ntohl(pd->tv_usec), \
			       ntohl(pd->echo_sec), ntohl(pd->echo_usec));
		    else 
			printf(" %d %d", ntohs(pd->round), pd->ipkt);
		    if (pd->ck0 == iph->saddr + (sport_id << 16) + dport_type) {
			printf ("\n");
		    } else
			printf ("chk0 err\n");
		} else {
		    printf("unknown pd->ver %d\n", pd->ver);
		}
	    } else
		printf("\n");
	    continue;
	}
	
	if (dmp_major_ver == 3) {
	    pdecode_t *pdec = (pdecode_t *)item;
    
	    printf("%u.%06u ", dmphdr.tv.tv_sec, dmphdr.tv.tv_usec);
	    printf("%u %u %u %u %u",
		   pdec->tos, ntohs(pdec->tot_len),         /* tos, tot_len */
		   ntohs(pdec->ipid),                       /* ipid */
		   pdec->ttl, pdec->protocol);              /* ttl, prot */
	    if (pdec->protocol != IPPROTO_ICMP) {
		printf(" %u %u",                         /* tcp/udp(sport,dport) */
		       ntohs(pdec->tcp.source),  
		       ntohs(pdec->tcp.dest));
		if (pdec->protocol == IPPROTO_TCP) {
		    printf(" %u %u %u %u", 
			   ntohl(pdec->tcp.seq), ntohl(pdec->tcp.ack_seq),
			   tcp_flag_byte(&pdec->tcp), ntohs(pdec->tcp.window));
		}
	    } else {
		printf(" %u %u",
		       ntohs(pdec->icmp.un.echo.id),                /* icmp(id,type) */
		       pdec->icmp.type);
	    }
	    printf(" %u %u\n", 
		   ntohs(pdec->round), pdec->ipkt);    /* iround,ipkt */
	}
    }
}
