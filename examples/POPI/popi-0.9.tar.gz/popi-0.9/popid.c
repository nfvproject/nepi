/*
 * $Author: lgh $
 * $Header: /data/cvsroot/plportest/src/popid.c,v 1.13 2007/01/22 13:54:22 lgh Exp $
 */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
/* atoi() */
#include <stdlib.h>
/* close() */
#include <unistd.h>
#include <pcap.h>
/* errno */
#include <errno.h>
/* assert */
#include <assert.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
/* basename() */
#include <libgen.h>
#include "common.h"
#include "monfun.h"
#include "popid.h"
#include "ctrld.h"
#include "send.h"
#include "utils.h"
#include "socket.h"
#include "dump.h"
#include "errfun.h"

#define MONPORT      55555

#ifdef PlanetLab
static int is_planetlab = 1;
#else
static int is_planetlab = 0;
#endif

char rev[REV_LEN]="$Revision: 1.13 $";
/* 
 * =================================
 * global vars
 * =================================
 */
/* server options */
u_int32_t local_ip;
char local_ip_str[20];
u_int32_t local_netmask;
u_int32_t lastcheck_tv_sec;
u_int32_t last_showalive;
char program_name[20];

/* 
 * ===============================
 * local defines, vars, funcs
 * ===============================
 */
#define ALIVE_INTVL 86400
#define MSL         600

static char popid_cfgfn[100];
static u_int32_t opt_monserver = 0;
static int opt_monport = MONPORT;
static int opt_daemonize = 0;
static int opt_verbose = 0;
static char opt_filter[255];
static int ctrl_listenfd;
static int snaplen = 65535;
static u_int16_t ctrlport = CTRLPORT;
static pktype_t bindpts[MAX_RAWPKTS];
static int nbindpts;
static probe_t probe0;
static struct timeval start_tv;
static int ipraw_sockfd;
static pcap_t *pcapfp;
static int pcap_ether = 1;

static void usage(void);
static int read_popid_conf(char *fname);
static void init_probe(probe_t *probe);
static void finish_probe(probe_t *probe);
static void periodic_check(int signo);
static void recv_packet(void);

void usage(void)
{
    printf(
"usage: popid [options]\n"
"  -h        show this help\n"
"  -b        bind packet types, e.g, 6/30002,17/30002,1/30002 (only available for PlanetLab)\n"
"  -c        specify popid configuration file\n"
"  -d        daemonize\n"
"  -i        interface (default eth0)\n"
"  -m        send message to monitor host:port\n"
"  -p        control port\n"
"  -v        verbose\n"
"  -V        show Version\n"
);
    exit(0);
}

int 
read_popid_conf(char *fname)
{
    FILE *fp;
    char line[500], *pstr, *pstr1;

    if ((fp = fopen(fname, "r")) == NULL) {
	err_ret("open %s error:", fname);
	return -1;
    }

    while(fgets(line, 500, fp)) {
	if (line[0] == '#')
	    continue;
	line[strlen(line) - 1] = '\0';
	/* for server */
	if (strstr(line, "monserver")) {
	    pstr = strchr(line, '=');
	    pstr1 = strchr(pstr+1, ':');
	    pstr1 = '\0';
	    inet_aton(pstr, (struct in_addr *)&opt_monserver);
	    opt_monport   = atoi(pstr1+1);
#ifdef DEBUG
	    dbg_msg("monserver = %s:%d\n", GET_IPSTR(opt_monserver), opt_monport);
#endif
	} else if (strstr(line, "ctrlport")) {
	    pstr = strchr(line, '=');
	    ctrlport = atoi(pstr+1);
#ifdef DEBUG
	    dbg_msg("ctrlport = %d\n", ctrlport);
#endif
	} else if (strstr(line, "filter")) {
	    pstr = strchr(line, '=');
	    if (line[strlen(line) - 1] == '\n')
		line[strlen(line) - 1] = '\0';
	    sprintf(opt_filter, "%s", pstr+1, 255);
#ifdef DEBUG
	    dbg_msg("filter = %s\n", opt_filter);
#endif
#ifdef PlanetLab
	} else if (strstr(line, "bind")) {
	    pstr = strchr(line, '=');
	    if (line[strlen(line) - 1] == '\n')
		line[strlen(line) - 1] = '\0';
	    nbindpts = create_pktypes(bindpts, MAX_RAWPKTS, pstr+1);
#endif
	} else {
	    err_ret("parse errer \"%s\" in %s\n", line, fname);
	    return (-1);
	}
    }
    fclose(fp);
    return 0;
}

void 
init_probe(probe_t *probe)
{
#ifdef DEBUG
    dbg_msg("probe init\n");
#endif
    memset(probe, 0, sizeof(probe_t));
    probe->th_seq = 10000;
    probe->dumpfd = -1;
    probe->ctrlfd = -1;
    probe->rpkt_ttl = -1;
}

void
finish_probe(probe_t *probe)
{
    char buf[100], *pkt;
    int i;
    pktype_t pt;

    if (probe->dumpfd >= 0) {
	sprintf(buf, "dump_eintr %d", probe->dump_eintr);
	dump_meta(probe->dumpfd, buf);
	close_dump(probe->dumpfd);
	probe->dumpfd = -1;
#ifdef DEBUG
	dbg_msg("close server dump file %s.dmp\n", probe->dumpfnpfx);
#endif
    }
    close(probe->ctrlfd);
    probe->ctrlfd = -1;
    probe->saddr = 0;
    /* free statfeed */
    if (probe->rcvpkts) free(probe->rcvpkts);
    /* refill the firewall holes for TCP */
#ifdef PlanetLab
    for (i = 0; i < probe->nrtcp; ++i) {
	pt.protocol = probe->rpts[i].protocol;
	pt.sport_id = probe->rpts[i].dport_type;
	pt.dport_type = probe->rpts[i].sport_id;
	pt.thflags = (TCP_FLAG_RST | TCP_FLAG_ACK);
	pt.th_seq  = htonl(probe->th_seq);         /* seq of RST larger the the maxseq sent so far */
	pt.th_ack  = htonl(probe->rpts[i].th_seq);
	pkt = prepare_tcp(&pt, probe->saddr, buf+40, 0);
	if (send_pkt(ipraw_sockfd, pkt, 40) < 0) {
	    err_ret("fail to send RST from localhost:%d to %s:%d", 
		    ntohs(pt.sport_id), GET_IPSTR(probe->saddr), ntohs(pt.dport_type));
	}
    }
#endif
#ifdef DEBUG
    dbg_msg("probe finished\n");
#endif
}

/* 
 * send alive message, finish the probe
 */
void 
periodic_check(int signo)
{
    struct timeval curtv;
    probe_t *probe = &probe0;

    gettimeofday(&curtv, NULL);
    if (curtv.tv_sec - last_showalive > ALIVE_INTVL) {
	send_monmsg("%s alive", rev);
	last_showalive = curtv.tv_sec;
    }
    if (probe->saddr != 0 && curtv.tv_sec - probe->last_tvsec > MSL) {
#ifdef DEBUG
	dbg_msg("MSL exceed %u - %u\n", curtv.tv_sec, probe->last_tvsec);
#endif
	finish_probe(probe);
    }
    alarm(CHECK_INTVL + 1);
}

void 
send_statfeed(probe_t *probe)
{
    static char feedbuf[MAX_STATFEED_LEN];
    rcvpkt_t *rpkt;
    int len;
    
    sprintf(feedbuf, "400");
    len = strlen(feedbuf);
    while (probe->rcvpkts[probe->rcvpkts_head].used) {
	rpkt = &probe->rcvpkts[probe->rcvpkts_head];
	sprintf(feedbuf+len, " %d,%d", rpkt->iround, rpkt->ipkt);
	rpkt->used = 0;
	len = strlen(feedbuf);
	if (len > MAX_STATFEED_LEN - 20) {
	    send_control_rsp(probe->ctrlfd, feedbuf);
	    sprintf(feedbuf, "400");
	    len = strlen(feedbuf);
	}
	probe->rcvpkts_head = (probe->rcvpkts_head + 1) % probe->rcvpkts_total;
    }
    if (len > 3)
	send_control_rsp(probe->ctrlfd, feedbuf);
}

void 
recv_packet(void)
{
    int pktlen, hlen, pfsock, maxrsockfd = 0, tmpfd;
    ssize_t nbytes;
    struct sockaddr_in from;
    struct iphdr *iph;
    struct tcphdr *th;
    struct udphdr *uh;
    struct icmphdr *icmph;
    datamx_t *pd;
    const unsigned char *pkt, *sndbuf;
    struct pcap_pkthdr pcap_h;
    u_int8_t protocol;
    probe_t *probe = &probe0;
    fd_set allrset, sock_rset;
    char pbuf[MAX_STATFEED_LEN];

    FD_ZERO(&allrset);
    FD_SET(ctrl_listenfd, &allrset);
    maxrsockfd = ctrl_listenfd;
    pfsock = pcap_fileno(pcapfp);
    FD_SET(pfsock, &allrset);
    if (pfsock > maxrsockfd)
	maxrsockfd = pfsock;

    while (1) {
	sock_rset = allrset;
	if (select(maxrsockfd + 1, &sock_rset, NULL, NULL, NULL) < 0) {
	    if (errno == EINTR)
		continue;
	    else {
		err_ret("select");
		continue;
	    }
	}
	/* process probe packets */
	if (FD_ISSET(pfsock, &sock_rset)) {
	    pkt = pcap_next(pcapfp, &pcap_h);
	    if (probe->ctrlfd < 0)
		continue;
        pktlen = pcap_h.len;
		if (pcap_ether && (pcap_h.len > 14) && ((pkt[14]&0xF0) == 0x40) || ((pkt[14]&0xF0) == 0x60) && ((pkt[14]&0x0F) >= 0x05)) {
	        pkt += 14;
	        pktlen -= 14;
        } else if (pcap_h.len <= 14) {
            pcap_ether = 0;
        }
        iph = (struct iphdr *)pkt;
	    /* only process sent from probe client */
	    if (iph->saddr != probe->saddr)
		continue;
	    protocol = iph->protocol;
	    switch (protocol) {
	    case IPPROTO_TCP:
		th = (struct tcphdr *)(iph + 1);
		pd = (datamx_t *)(pkt + 40);
		hlen = 40;
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("[%s] saddr=%s (p%u,s%u,d%u) thflags%d len%d (%u,%u)\n", 
			__func__,
			GET_IPSTR(iph->saddr),
			iph->protocol, ntohs(th->source), ntohs(th->dest),
			tcp_flag_byte(th),
			pktlen, ntohs(pd->round), pd->ipkt);
#endif
		break;
	    case IPPROTO_UDP:
		uh = (struct udphdr *)(iph + 1);
		pd = (datamx_t *)(pkt + 28);
		hlen = 28;
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("[%s] saddr=%s (p%u,s%u,d%u) len%d (%u,%u)\n", 
			__func__,
			GET_IPSTR(iph->saddr),
			iph->protocol, ntohs(uh->source), ntohs(uh->dest),
			pktlen, ntohs(pd->round), pd->ipkt);
#endif
		break;
	    case IPPROTO_ICMP:
		icmph = (struct icmphdr *)(iph + 1); 
		pd = (datamx_t *)(pkt + 28);
		hlen = 28;
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("[%s] saddr=%s (p%u,s%u,d%u) len%d (%u,%u)\n", 
			__func__,
			GET_IPSTR(iph->saddr),
			iph->protocol, ntohs(icmph->un.echo.id), icmph->type,
			pktlen, ntohs(pd->round), pd->ipkt);
#endif
		break;
	    default:
		continue;
	    }
	    /* remember forward path ttl */
	    if (protocol == IPPROTO_TCP && ntohs(th->dest) == ctrlport) {
		probe->rpkt_ttl = iph->ttl;
		continue;
	    }
	    /* 
	     * process incoming packets to:
	     * 1. respond to SYN packet,
	     * 2. respond receive statistics via control channel.
	     */
	    /* response SYN with SYN/ACK. only for those without payload */
	    if (protocol == IPPROTO_TCP && th->syn && !th->ack && 
		ntohs(iph->tot_len) == 40) {
		int i;
		sndbuf = prepare_synack(th, iph->saddr, probe->th_seq);
		if (send_pkt(ipraw_sockfd, sndbuf, 40) < 0)
		    err_ret("[%s] send synack", __func__);
		for (i = 0; i < probe->nrtcp; ++i) {
		    if (probe->rpts[i].sport_id == th->source
			&& probe->rpts[i].dport_type == th->dest) {
			probe->rpts[i].th_seq = ntohl(th->seq);
			break;
		    }
		}
		if (i == probe->nrtcp) {
		    probe->rpts[i].sport_id = th->source;
		    probe->rpts[i].dport_type = th->dest;
		    probe->rpts[i].th_seq = ntohl(th->seq);
		    probe->nrtcp++;
		    assert(probe->nrtcp <= probe->nrpts);
		}
		continue;
	    }
	    /* dump all received packets from popi */
	    if (probe->dumpfd >= 0) {
		if (dump_packet(probe->dumpfd, pcap_h.ts, pkt, pktlen) < 0) {
		    if (errno == EINTR) {
			probe->dump_eintr++;
		    } else {
			char rsp[255];
			sprintf(rsp, "500 %s", strerror(errno));
			send_control_rsp(probe->ctrlfd, rsp);
			close(probe->dumpfd);
			probe->dumpfd = -1;
		    }
		}
	    }
	    if (!probe->statfeed) 
		continue;
	    /* ignore packets do not contain PREAMBLE,
	       or packets failed to achieve PREAMBLE */
	    if (pktlen < hlen + POPIHDRLEN
		||
		(pktlen >= hlen + POPIHDRLEN && in_cksum((unsigned short *)pd, POPIHDRLEN))) {
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("dmx_err:%d,%d,%d,%d,%d,%d,%d\n", 
			pd->hlen, ntohs(pd->round), pd->ipkt, pd->ver, 
			ntohs(pd->magic), ntohl(pd->tv_sec), ntohl(pd->echo_sec));
#endif
		continue;
	    }
	    /* store received packets */
	    if (!probe->rcvpkts[probe->rcvpkts_tail].used) {
		probe->rcvpkts[probe->rcvpkts_tail].used = 1;
		probe->rcvpkts[probe->rcvpkts_tail].iround = ntohs(pd->round);
		probe->rcvpkts[probe->rcvpkts_tail].ipkt = pd->ipkt;
		probe->rcvpkts_tail = (probe->rcvpkts_tail+1) % probe->rcvpkts_total;
	    } else {
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("missed\n");
#endif
		probe->rcvpkts_missed++;
	    }
	}
	/* accept control connection */
	if (FD_ISSET(ctrl_listenfd, &sock_rset)) {
	    if ((tmpfd = accept_conn(ctrl_listenfd, &from)) == -1)
		continue;
	    /* current control channel occupied? */
	    if (probe->ctrlfd >= 0) {
#ifdef DEBUG
		dbg_msg ("1 limit reached. Discard new arrived control channel request.\n");
#endif
		close(tmpfd);
	    } else {
		FD_SET(tmpfd, &allrset);
		if (tmpfd > maxrsockfd)
		    maxrsockfd = tmpfd;
		init_probe(probe);
		probe->saddr  = from.sin_addr.s_addr;
		probe->ctrlfd = tmpfd;
		dbg_msg ("popi client %s connected.\n", GET_IPSTR(probe->saddr));
	    }
	}
	/* process control command */
	if (probe->ctrlfd >= 0 && FD_ISSET(probe->ctrlfd, &sock_rset)) {
	    nbytes = readline_cbuf(probe->ctrlfd, &probe->cbuf, pbuf);
	    if (nbytes <= 0) {
		/* control channel closed, either expected or unexpected. 
		   we end this probe. */
		FD_CLR(probe->ctrlfd, &allrset);
		if (pfsock > ctrl_listenfd)
		    maxrsockfd = pfsock;
		else
		    maxrsockfd = ctrl_listenfd;
		dbg_msg( "popi client %s disconnected.\n", GET_IPSTR(probe->saddr));
		finish_probe(probe);
	    } else 
		handle_ctrlcmd(probe, pbuf);
	}
    }
}

int 
main(int argc, char *argv[])
{
    char line[255], *pstr;
    char ifname[10] = "eth0";
    int c;
#ifdef PlanetLab
    int i;
#endif

    strncpy(program_name, basename(argv[0]), 20);
    gettimeofday(&start_tv, NULL);
    lastcheck_tv_sec = start_tv.tv_sec;
    last_showalive = start_tv.tv_sec;
    // sprintf(line, "%s/etc/popid.conf", getenv("HOME"));
    // strcpy(popid_cfgfn, line);
    assert(sizeof(datamx_t) == 30);

    while ((c = getopt(argc, argv, "b:c:dhi:m:p:s:vV")) != EOF) {
	switch(c) {
	case 'b':
#ifdef PlanetLab
	    nbindpts = create_pktypes(bindpts, MAX_RAWPKTS, optarg);
#else
	    fprintf(stderr, "-b option is not available for non-PlanetLab host\n");
	    exit(1);
#endif
	    break;
	case 'c':
	    strcpy(popid_cfgfn, optarg);
	    break;
	case 'd':
	    opt_daemonize = 1;
	    break;
	case 'h':
	    usage();
	    break;
	case 'i':
	    strncpy(ifname, optarg, 10);
	    break;
	case 'm':
	    opt_monport = atoi(optarg);
	    break;
	case 'p':
	    ctrlport = atoi(optarg);                                 	    /* server listen port */
	    break;
	case 's':
	    snaplen = atoi(optarg);
	    if (snaplen == 0)
		snaplen = 65535;
	case 'v':
	    opt_verbose++;
	    break;
	case 'V':
	    dbg_msg("%s\n", rev);
	    exit(0);
	default:
	    err_msg("no such option!");
	    usage();
	}
    }

    if (get_local_ip(local_ip_str, &local_ip, &local_netmask, ifname) == -1)
	err_quit("found no local_ip for %s", ifname);

    /* read popid configuration */
    if (popid_cfgfn[0] != '\0') {
	if (read_popid_conf(popid_cfgfn) < 0)
	    exit(1);
    }

    /* open a UDP socket to send to our central monitor */
    if (opt_monserver)
    	open_monsock(opt_monserver, opt_monport);
    /* Open pcap, raw socket, bind ports, control channel */
    if (opt_filter[0] == '\0')
	sprintf(opt_filter, "!src host %s", local_ip_str);
    else {
	sprintf(line, " && !src host %s", local_ip_str);
	strcat(opt_filter, line);
    }
    dbg_msg("pcap_filter: %s\n", opt_filter);
    pcapfp = open_pcap(ifname, snaplen, opt_filter);
    ipraw_sockfd = open_rawsend();
#ifdef PlanetLab
    /* bind ports */
    for (i = 0; i < nbindpts; ++i) {
	if (bind_port(bindpts[i].protocol, bindpts[i].sport_id) < 0)
	    exit(1);
    }
#endif
    probe0.ctrlfd = -1;
    ctrl_listenfd = listen_control_channel(ctrlport);
    if (ctrl_listenfd < 0) 
	err_quit("open control channel failed");
    dbg_msg("control port listened at %s:%d\n", local_ip_str, ctrlport);
    
    /* daemonize */
    if (opt_daemonize) {
	sprintf(line, "%s/log/%s.popid.log", getenv("HOME"), local_ip_str);
	if (open_logfile(line) == -1)
	    err_sys("cannot open %s", line);
	if (daemon(1, 0) == -1)
	    err_sys("cannot daemonized");
	daemonized = 1;
    }
    send_monmsg("%s started", rev);

    signal(SIGALRM, periodic_check); 
    recv_packet();

    return(0);
}

void
get_pcap_stats(struct pcap_stat *ps)
{
    pcap_stats(pcapfp, ps);
}

int
is_planetlab_popid()
{
    return is_planetlab;
}
