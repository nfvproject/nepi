/* portable open raw socket functions on PlanetLab and ordinary Linux box */

#ifndef _SOCKET_H_
#define _SOCKET_H_

#include <sys/types.h>
#include <pcap.h>

extern int set_sock_rcvbuf(int, int);
extern int set_sock_sndbuf(int, int);
extern int set_sock_block(int);
extern int set_sock_nonblock(int);
extern int get_local_ip(char *, u_int32_t*, u_int32_t*, const char *);
extern int open_rawsend(void);
extern pcap_t *open_pcap(char *, int, char *);
#ifdef PlanetLab
extern int bind_port(u_int8_t protocol, u_int16_t sport_id);
#endif

#endif
