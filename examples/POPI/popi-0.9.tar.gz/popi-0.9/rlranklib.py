#!/usr/bin/env python
#
# provide relative rank method
# 
# $Header: /data/cvsroot/plportest/anadata/rlranklib.py,v 1.11.2.1 2007/11/26 08:46:29 lgh Exp $

import random
from rpy import *
from math import sqrt, log
from sets import Set

safe_eff = [None,1.365,1.208,1.116,1.110,1.104,1.064,1.064]

def calc_rlrank(lrs, opt_ranktype):
    """return relative rank

    >>> calc_rlrank([[3,1],[9,3],[10,3],[11,5]],0)
    [[3, 0.25], [9, 0.625], [10, 0.625], [11, 1.0]]
    >>> calc_rlrank([[3,1],[9,3],[10,3],[11,0.5]],0)
    [[11, 0.25], [3, 0.5], [9, 0.875], [10, 0.875]]
    """
    ranks = calc_rank(lrs, opt_ranktype)
    n = len(ranks)
    return ([[rank[0], rank[1]/n] for rank in ranks])
        
def calc_rank(lrs, opt_ranktype):
    """return ranks

    lrs : [[index, nrecv, ...], [index, nrecv, ...], ...]

    >>> calc_rank([[3,1],[9,3],[10,3]],0)
    [[3, 1.0], [9, 2.5], [10, 2.5]]
    >>> calc_rank([[3.5,3],[9,3],[10,3]],0)
    [[3.5, 2.0], [9, 2.0], [10, 2.0]]
    """
    lrs.sort(lambda x,y : cmp(x[1], y[1]))
    ranks = [] # ranks = [[lr[0], -1] for lr in lrs]
    maxnrecv = lrs[-1][1]
    lrs.append([-1, maxnrecv + 1])  # last packet, will not include in ranks.

    # assign rank to sorted packet type, begin from 1,2,...
    lastnrecv = lrs[0][1]
    tranks = [1]
    for i in range(1, len(lrs)):
        if lrs[i][1] == lastnrecv:
            tranks.append(i+1)
        else:
            # equal value for tied ranks: http://faculty.vassar.edu/lowry/ch11a.html
            if opt_ranktype == 0:
                mean_rank = float(sum(tranks)) / len(tranks)
                for j in range(min(tranks)-1, max(tranks)):
                    ranks.append([lrs[j][0], mean_rank])
            # using randomized ranks to resolve ties (strictly increasing)
            else:
                random.shuffle(tranks)
                for j in range(min(tranks)-1, max(tranks)):
                    ranks.append([lrs[j][0], float(tranks[j])])
            lastnrecv = lrs[i][1]
            tranks = [i+1]

    return ranks

def null_hypo(partition, rlranks, ncluster, nb, alpha, verbose=0):

    for igrp in range(1, ncluster+1):
        riag = [ rlranks[i] for i in range(0, len(rlranks)) if partition[i] == igrp ]    # rlranks in a group
        if len(riag) == 1:
            continue
        threshold = r.qtukey(alpha, len(riag), 1000)*sqrt(1.0/12/nb)*len(riag)/len(rlranks)
        range_    = max(riag) - min(riag)
        if verbose:
            print "   ", igrp, len(riag), min(riag), max(riag), range_, "%.3f" % threshold,
            if verbose > 1:
                print [ "%.3f" % x for x in riag ],
            print ""

        if range_ > threshold:
            return False

    return True

def kpartition(rlranks, nb, nstart_opt, alpha, verbose=0):
    """using k-means to cluster"""

    ncluster = 1
    partition = [1]*len(rlranks)
    while null_hypo(partition, rlranks, ncluster, nb, alpha, verbose=verbose) == False:
        ncluster += 1
        cl = r.kmeans(rlranks, ncluster, nstart = nstart_opt)
        partition = cl['cluster']
        if verbose:
            print ncluster, ":", ",".join([ str(x) for x in partition ])

    return partition

def null_hypo_rec(arrs, nb, alpha, ksum, verbose):
    km = len(arrs)
    if km == 1:
        return True
    
    # t = r.qtukey(alpha, len(arrs), 1000)*sqrt(1.0/12/nb)*(len(arrs)+1)/ksum
    t = r.qtukey(alpha, km, 1000) * sqrt((km*km-1)/12.0/nb) / ksum
    if km <= len(safe_eff):
        t = t * safe_eff[km-1]
    if max(arrs) - min(arrs) > t:
        return False
    return True

def kpart_rec(arrs, nb, alpha, ksum, verbose):
    """Recursive cluster method using k-means"""

    km = len(arrs)
    partition = [1]*km
    if null_hypo_rec(arrs, nb, alpha, ksum, verbose) == False:
        if km == 2:
            partition = [1,2]
            if verbose:
                print "%d:" % (km),
                for i in range(0, km):
                    print "%.2f/%d" % (arrs[i], partition[i]),
                print ""
        else:
            cl = r.kmeans(arrs, 2, nstart = km)
            if verbose:
                print "%d:" % (km),
                for i in range(0, km):
                    print "%.2f/%d" % (arrs[i], cl['cluster'][i]),
                print ""
            partition = cl['cluster']
            arrs1 = [ arrs[i] for i in range(0, km) if partition[i] == 1 ]
            arrs2 = [ arrs[i] for i in range(0, km) if partition[i] == 2 ]
            part1 = kpart_rec(arrs1, nb, alpha, ksum, verbose)
            part2 = kpart_rec(arrs2, nb, alpha, ksum, verbose)
            maxpart1 = max(part1)
            ipart1 = 0
            ipart2 = 0
            # combine the two partitions
            for i in range(0, km):
                if partition[i] == 1:
                    partition[i] = part1[ipart1]
                    ipart1 += 1
                else:
                    partition[i] = part2[ipart2] + maxpart1
                    ipart2 += 1
                    
    return partition

def part_sort(arrs, part):
    """renumber igroup according the ARR. The larger ARR, the larger igroup"""
    pair = [ [arrs[i], part[i], i] for i in range(0, len(part)) ]
    pair.sort(lambda x, y: cmp(x[0], y[0]))
    
    igroup_prev = 0
    j = 0
    for i in range(0, len(pair)):
        if pair[i][1] != igroup_prev:
            j += 1
            igroup_prev = pair[i][1]
        pair[i][1] = j

    pair.sort(lambda x, y: cmp(x[2], y[2]))
    return([ x[1] for x in pair ])

def cmp_clres(part0, part):
    """compare two partition result, return the difference

    idea:
    1. Sort actual and inferred partition groups by
    their number of packets.
    2. find pair the groups with maximum mutual number
    of packets, then find next largest.
    3. ignore group number < 0

    >>> cmp_clres([1,2,1,3], [1,2,1,3])
    0
    >>> cmp_clres([1,2,1,3], [1,2,2,3])
    2
    >>> cmp_clres([1,2,1,3], [2,1,2,3])
    0
    >>> cmp_clres([1,2,1,3], [3,3,3,3])
    2
    """
    
    gsets_true = []
    gsets_infer = []
    for i in range(1, max(part0)+1):
        gsets_true.append(Set([ j for j in range(0, len(part0)) if part0[j] == i ]))
    for i in range(1, max(part)+1):
        gsets_infer.append(Set([ j for j in range(0, len(part)) if part[j] == i ]))
    gsets_true.sort(lambda x, y: -cmp(len(x), len(y)))
    gsets_infer.sort(lambda x, y: -cmp(len(x), len(y)))

    nmiss = 0
    for gsi in gsets_infer:
        nunion_max = [0, None, 0]
        for gst in gsets_true:
            nunion = len(gsi & gst)
            if  nunion > nunion_max[0]:
                nunion_max = [nunion, gst, len(gsi - gst)]
        if nunion_max[1]:
            nmiss += nunion_max[2]
            gsets_true.remove(nunion_max[1])
        else:
            nmiss += len(gsi)

    return nmiss

def LR_test(x, n, v, alpha):
    """likelihood ratio test

    Xuan Lu, Applied Statistics, Tsinghua University"""
    Y = [0]*(v+1)
    lnL = [0]*(v+1)
    for i in range(0, v+1):
        Y[i] = float(x[i])/n[i]
        if x[i] == 0 or x[i] == n[i]:
            lnL[i] = 0
        else:
            lnL[i] = x[i]*log(Y[i], 2) + (n[i]-x[i])*log((1-Y[i]), 2)
    LR = 2 * (sum(lnL[0:v]) - lnL[v])
    thresh = r.qchisq(1-alpha, v-1)
    # print x, n, Y, LR, thresh
    if LR > r.qchisq(1-alpha, v-1):
        return (False, LR, thresh)
    return (True, LR, thresh)

def _test():
    import doctest
    doctest.testmod()
    
if __name__ == '__main__':
    _test()
