/* config.h.  Generated from config.h.in by configure.  */
/* Debugging Output */
#define DEBUG -1

/* Have ifaddr.h */
#define HAVE_IFADDRS_H 1

/* Have getifaddrs() */
#define HAVE_GETIFADDRS 1

/* Host type */
/* #undef PlanetLab */

/* Use libproper */
/* #undef PLPROPER */
