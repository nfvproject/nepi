#ifndef _COMMON_H_
#define _COMMON_H_

/* packets */
#define DEBUG_P 2
/* control channel */
#define DEBUG_C 4

#endif
