#ifndef _DUMP_H_
#define _DUMP_H_

/* 
 * DMP_MAJOR_VER = 0: very old format
 * DMP_MAJOR_VER = 1: dmp all packet header
 * DMP_MAJOR_VER = 2: 
 *  DMP_MINOR_VER = 1: only dmp ts, tos, ttl, iplen, protocol, sport, dport, round, ipkt 
 *  DMP_MINOR_VER = 2: dump ip(partial), tcp(all), round, ipk
 * DMP_MAJOR_VER = 3:
 *  time | len | flag | pkt or meta data
 */

int open_dump(char *filename, u_int16_t dmplen, u_int8_t mver, char *errbuf);
void close_dump(int fd);
int dump_meta(int fd, const char *);
int dump_packet(int fd, struct timeval tv, const char *pkt, int pktlen);

#endif
