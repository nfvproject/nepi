#include <sys/types.h>
/* free() */
#include <stdlib.h>
#include <string.h>
#include <strings.h>
/* isdigit() */
#include <ctype.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>
#include <sys/socket.h>
#include <errno.h>

#include "common.h"
#include "utils.h"
#include "errfun.h"
#include "send.h"

extern u_int32_t local_ip;

int tcp_csum_error = 0;
int udp_csum_error = 0;
int icmp_csum_error = 0;

int 
create_pktypes(pktype_t *pts, int npt, const char *arg)
{
    char buf[255], *pstr, *sep0, *sep1, *p;
    pktype_t *pt;
    int ipt = 0;

    strncpy(buf, arg, 255);
    pstr = buf;
    while (pstr) {
	if (ipt >= npt) return(-2);
	pt = &pts[ipt];
	memset(pt, 0, sizeof(pktype_t));
	/* seperate packet types by ',' */
	sep0 = strchr(pstr, ',');
	if (sep0) *sep0 = '\0';
	/* protocol */
	sep1 = strchr(pstr, '/');
	if (!sep1) return -1;
	*sep1 = '\0';
	pt->protocol = atoi(pstr);
	/* sport */
	pstr = sep1+1;
	sep1 = strchr(pstr, '/');
	if (!sep1) {
	    /* not have dport */
	    pt->sport_id = atoi(pstr);	    
	} else {
	    /* have dport */
	    *sep1 = '\0';
	    pt->sport_id = atoi(pstr);
	    /* dport */
	    pstr = sep1+1;
	    /* tcp flag */
	    if (pt->protocol == IPPROTO_TCP) {
		p = pstr;
		while (*p && isdigit(*p)) {
		    p++;
		}
		while (*p) {
		    switch (*p) {
		    case 's':
			pt->thflags |= TCP_FLAG_SYN;
			break;
		    case 'a':
			pt->thflags |= TCP_FLAG_ACK;
			break;
		    case 'r':
			pt->thflags |= TCP_FLAG_RST;
			break;
		    default:
			err_msg("parse tcp flags error");
			return -1;
		    }
		    *p++ = '\0';
		}
	    }
	    /* dport */
	    pt->dport_type = atoi(pstr);
	}
#ifdef DEBUG
	dbg_msg("%d %u %u %u %x\n", ipt, pt->protocol, pt->sport_id, pt->dport_type, pt->thflags);
#endif
	ipt++;
	if (sep0)
	    pstr = sep0 + 1;
	else
	    pstr = NULL;
    }
    return ipt;
}

char *
ptstr(pktype_t *pt)
{
    static char str[20];
    switch (pt->protocol) {
    case 6:
	str[0] = 't';
	break;
    case 17:
	str[0] = 'u';
	break;
    case 1:
	str[0] = 'i';
	break;
    default:
	str[0] = 'x';
    }
    sprintf(str+1, "%d/%d", pt->sport_id, pt->dport_type);
    return str;
}


char *
prepare_synack(struct tcphdr *th, u_int32_t daddr, u_int32_t th_seq)
{
    static char buf[100];
    pktype_t pt;

    pt.protocol   = IPPROTO_TCP;
    pt.sport_id   = ntohs(th->dest);
    pt.dport_type = ntohs(th->source);
    pt.thflags    = (TCP_FLAG_SYN | TCP_FLAG_ACK);
    pt.th_seq     = th_seq;
    pt.th_ack     = ntohl(th->seq) + 1;       /* do not ack the data contained in the SYN */
#if ((DEBUG) & (DEBUG_C))
    dbg_msg("[%s] (6,s%d,p%d)\n", __func__, pt.sport_id, pt.dport_type);
#endif
    return(prepare_tcp(&pt, daddr, buf+40, 0));
}

char *
prepare_tcp(pktype_t *pktype, u_int32_t daddr, char *buf, int dlen)
{
    struct tcphdr *th = (struct tcphdr *)(buf-20);
    struct pseudohdr *psh = (struct pseudohdr *)(buf-20-12);
    
    bzero((char *)th, sizeof(struct tcphdr));
    th->source = htons(pktype->sport_id);
    th->dest   = htons(pktype->dport_type);
    th->doff   = 5;
    th->window = htons(32768);
    tcp_flag_byte(th) |= pktype->thflags;
    th->seq     = htonl(pktype->th_seq);
    th->ack_seq = htonl(pktype->th_ack);

    bzero((char *)psh, sizeof(struct pseudohdr));
    psh->srcip = local_ip;
    psh->dstip = daddr;
    psh->zero  = 0;
    psh->prot  = IPPROTO_TCP;
    psh->len   = htons(20+dlen);
    if (tcp_csum_error)
	th->check = in_cksum_err((unsigned short *)psh, 20 + dlen + sizeof(struct pseudohdr));
    else
	th->check = in_cksum((unsigned short *)psh, 20 + dlen + sizeof(struct pseudohdr));

    return(prepare_ip(pktype, daddr, buf-20, dlen+20));
}

char *
prepare_udp(pktype_t *pktype, u_int32_t daddr, char *buf, int dlen)
{
    struct udphdr *uh = (struct udphdr *)(buf-8);
    struct pseudohdr *psh = (struct pseudohdr *)(buf-8-12);

    bzero((char *)uh, sizeof(struct tcphdr));
    uh->source = htons(pktype->sport_id);
    uh->dest   = htons(pktype->dport_type);
    uh->len    = htons(dlen+8);
    bzero((char *)psh, sizeof(struct pseudohdr));
    psh->srcip = local_ip;
    psh->dstip = daddr;
    psh->zero  = 0;
    psh->prot  = IPPROTO_UDP;
    psh->len   = htons(dlen+8);
    if (udp_csum_error)
	uh->check  = in_cksum_err((unsigned short *)psh, 20 + dlen + sizeof(struct pseudohdr));
    else
	uh->check  = in_cksum((unsigned short *)psh, 20 + dlen + sizeof(struct pseudohdr));
    
    return(prepare_ip(pktype, daddr, buf-8, dlen+8));
}

char *
prepare_icmp(pktype_t *pktype, u_int32_t daddr, char *buf, int dlen)
{
    struct icmphdr *icmph = (struct icmphdr *)(buf - 8);
    
    icmph->type = (unsigned char)pktype->dport_type;
    icmph->code = 0;
    icmph->un.echo.id = htons(pktype->sport_id);
    icmph->un.echo.sequence = htons(10000);
    icmph->checksum = 0;
    if (icmp_csum_error)
	icmph->checksum = in_cksum_err((unsigned short *)icmph, dlen+8);
    else
	icmph->checksum = in_cksum((unsigned short *)icmph, dlen+8);

    return(prepare_ip(pktype, daddr, buf-8, dlen+8));
}

char *
prepare_ip(pktype_t *pktype, u_int32_t daddr, char *buf, int len)
{
    struct iphdr *iph = (struct iphdr *)(buf-20);

    bzero((char *)iph, sizeof(struct iphdr));
    iph->ihl      = 5;
    iph->version  = 4;
    iph->tot_len  = htons(len + 20);
    iph->frag_off = htonl(0x4000);
    iph->ttl      = 64;
    iph->protocol = pktype->protocol;
    iph->daddr    = daddr;

    return((char *)(buf-20));
}

int
send_pkt(int sockfd, const char *buf, int len)
{
    struct sockaddr_in sin;
    struct iphdr *iph = (struct iphdr *)buf;

    bzero((char *)&sin, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = iph->daddr;
 sendto:
    if (sendto(sockfd, buf, len, 0, (struct sockaddr *)&sin, sizeof(struct sockaddr_in)) < 0) {
	if (errno == ENOBUFS || errno == EINTR)
	    goto sendto;
	else {
	    err_ret("sendto error:");
	    return -1;
	}
    }
    return 0;
}
