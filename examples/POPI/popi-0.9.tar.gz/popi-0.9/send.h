#ifndef _SEND_H_
#define _SEND_H_
#include <netinet/tcp.h>

typedef struct {
    u_int8_t protocol;
    u_int16_t dport_type, sport_id;
    u_int32_t th_seq, th_ack;
    u_int8_t thflags;
} pktype_t;

/* TCP/UDP pseudo header */
struct pseudohdr {
    u_int32_t srcip;
    u_int32_t dstip;
    u_int8_t zero;
    u_int8_t prot;
    u_int16_t len;
} __attribute__ ((packed));

/*
 *  The union cast uses a gcc extension to avoid aliasing problems
 *  (union is compatible to any of its members)
 *  This means this part of the code is -fstrict-aliasing safe now.
 */
union tcp_byte_hdr {
    struct tcphdr hdr;
    u_int8_t bytes[20];
};
#define tcp_flag_byte(tp) ( ((union tcp_byte_hdr *)(tp))->bytes [13])

enum {
    TCP_FLAG_CWR = 0x80,
    TCP_FLAG_ECE = 0x40,
    TCP_FLAG_URG = 0x20,
    TCP_FLAG_ACK = 0x10,
    TCP_FLAG_PSH = 0x08,
    TCP_FLAG_RST = 0x04,
    TCP_FLAG_SYN = 0x02,
    TCP_FLAG_FIN = 0x01
};

char *prepare_synack(struct tcphdr *th, u_int32_t daddr, u_int32_t th_seq);
char *prepare_icmp(pktype_t *pktype, u_int32_t daddr, char *buf, int dlen);
char *prepare_udp(pktype_t *pktype, u_int32_t daddr, char *buf, int dlen);
char *prepare_tcp(pktype_t *pktype, u_int32_t daddr, char *buf, int dlen);
char *prepare_ip(pktype_t *pktype, u_int32_t daddr, char *buf, int len);
int send_pkt(int sockfd, const char *buf, int len);
int create_pktypes(pktype_t *pts, int npt, const char *arg);
char *ptstr(pktype_t *pt);

extern int tcp_csum_error;
extern int udp_csum_error;
extern int icmp_csum_error;

#endif
