#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <string.h>
/* fopen() */
#include <stdio.h>
/* errno */
#include <errno.h>
#include "dump.h"
/* htons */
#include <netinet/in.h>
#include <netinet/ip.h>
/* gettimeofday */
#include <sys/time.h>
#include <time.h>


#define REV_LEN 20

static u_int8_t dmp_major_ver;
static u_int8_t dmp_minor_ver;
static u_int16_t pktdmplen;

/*
 * open dumpfile
 * RETURN:
 *    dumpfd  on success
 *    -1      on fail
 */
int 
open_dump(char *filename, u_int16_t dmplen, u_int8_t mver, char *errbuf)
{
    FILE *fp;
    int fd;
    u_int16_t i;
    static char rev[20];

    if (mver == 3) {
	dmp_major_ver = 3;
	dmp_minor_ver = 1;
	pktdmplen = 32;
    } else if (mver == 4) {
	dmp_major_ver = 4;
	dmp_minor_ver = 0;
	pktdmplen = dmplen;
    } else {
	sprintf(errbuf, "dmp_major_ver %d not supported", mver);
	return -1;
    }
    
    if ((fp = fopen(filename, "r")) == NULL) {
	if ((fp = fopen(filename, "w")) == NULL) {
	    sprintf(errbuf, "%s", strerror(errno));
	    return -1;
	}
    } else {
	sprintf(errbuf, "%s already exist", filename);
	return -1;
    }
    fd = fileno(fp);
    /* write dump header */
    write(fd, &dmp_major_ver, 1);
    write(fd, &dmp_minor_ver, 1);
    i = htons(pktdmplen);        /* for cross-platform support, pktdmplen */
    write(fd, &i, 2);
    write(fd, rev, REV_LEN);
    // fsync(fd);              /* Turning sync on cause lots of packet drops on PlanetLab */
    return fd;
}

/* 
/* as we only dump very limited info. of the
 * packet, we need to do more checks on the
 * packet */
int
dump_packet(int fd, struct timeval tv, const char *pkt, int pktlen)
{
    static struct iovec vcts[10];
    static char typeflag = 0;
    static short len;
    struct iphdr *iph = (struct iphdr *)pkt;
    int pd_offset;
    u_int16_t dlen = pktdmplen;

    tv.tv_sec = htonl(tv.tv_sec);
    tv.tv_usec = htonl(tv.tv_usec);
    if (dmp_major_ver == 4)
	dlen = (pktlen < pktdmplen) ? pktlen: pktdmplen;
    len = htons(dlen);
    vcts[0].iov_base = (void *)&tv;          /* ts */
    vcts[0].iov_len  = 8;
    vcts[1].iov_base = (void *)&len;
    vcts[1].iov_len  = 2;
    vcts[2].iov_base = (void *)&typeflag;    /* pkt : typeflag = 0 */
    vcts[2].iov_len  = 1;
    if (dmp_major_ver == 3) {
	vcts[3].iov_base = (void *)(pkt + 1);    /* tos, tot_len, ipid, frag_off, ttl, prot */
	vcts[3].iov_len  = 9;
	vcts[4].iov_base = (void *)(pkt + 20);   /* tcp:(all)
						    udp:(sport,dport,len,ck)
						    icmp:(type,code,ck,id,seq) */
	vcts[4].iov_len  = 20;
	switch (iph->protocol) {
	case IPPROTO_TCP:
	    pd_offset = 40;
	    break;
	case IPPROTO_ICMP:
	    pd_offset = 28;
	    break;
	case IPPROTO_UDP:
	    pd_offset = 28;
	    break;
	default:
	    pd_offset = 20;
	}
	vcts[5].iov_base = (void *)(pkt + pd_offset + 1);  /* pd->round, pd->ipkt */
	vcts[5].iov_len  = 3;
	return (writev(fd, vcts, 6));
    } else if (dmp_major_ver == 4) {
	vcts[3].iov_base = (void *)pkt;
	vcts[3].iov_len  = dlen;
	return (writev(fd, vcts, 4));
    }
}

int
dump_meta(int fd, const char *buf)
{
    static struct timeval curtv;
    static struct iovec vcts[4];
    static char typeflag = 1;
    static short metalen;

    gettimeofday(&curtv, NULL);
    curtv.tv_sec  = htonl(curtv.tv_sec);
    curtv.tv_usec = htonl(curtv.tv_usec);
    metalen = htons(strlen(buf));

    vcts[0].iov_base = (void *)&curtv;
    vcts[0].iov_len  = 8;
    vcts[1].iov_base = (void *)&metalen;
    vcts[1].iov_len  = 2;
    vcts[2].iov_base = (void *)&typeflag;
    vcts[2].iov_len  = 1;
    vcts[3].iov_base = (void *)buf;
    vcts[3].iov_len  = ntohs(metalen);

    return(writev(fd, vcts, 4));
}

void
close_dump(int fd)
{
    dump_meta(fd, "close dump");
    close(fd);
}
