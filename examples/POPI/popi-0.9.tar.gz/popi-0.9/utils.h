#ifndef _UTILS_H_
#define _UTILS_H_
#include <sys/types.h>

typedef struct {
#define CRCVBUF_LEN 4096
    char buf[CRCVBUF_LEN];
    int head;
    int tail;
} cbuf_t;

#define MAX_RNDSEQ 256
typedef struct {
    u_int8_t d[MAX_RNDSEQ];
    int n;
} rndseq_t;

#define GET_IPSTR(x)   inet_ntoa(*(struct in_addr  *)&(x))

u_int16_t in_cksum_err(u_int16_t *, int);
u_int16_t in_cksum(u_int16_t *, int);
char **split_string(char *str, int *argc);
ssize_t readline_cbuf(int fd, cbuf_t *pcbuf, char *pbuf);
rndseq_t *create_rndseq(int n);
int fetch_from_rndseq(rndseq_t *rndseq);

#endif
