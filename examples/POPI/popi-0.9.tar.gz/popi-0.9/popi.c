/*
 * $Author: lgh $
 * $Header: /data/cvsroot/plportest/src/popi.c,v 1.15 2007/01/22 13:54:22 lgh Exp $
 */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/uio.h>
#include <stdio.h>
#include <signal.h>
/* basename() */
#include <libgen.h>

#include "common.h"
#include "errfun.h"
#include "monfun.h"
#include "send.h"
#include "dump.h"
#include "utils.h"
#include "socket.h"
#include "ctrl.h"
#include "popi.h"

#define BUFSIZE 2048

char rev[REV_LEN]="$Revision: 1.15 $";
int opt_verbose;
u_int32_t local_ip;
u_int32_t local_netmask;
char local_ip_str[20];
char program_name[20];

#ifdef PlanetLab
static int is_planetlab = 1;
#else
static int is_planetlab = 0;
#endif

static u_int16_t ctrlport = CTRLPORT;
static cprobe_t cprobe0;
static int probe_finish = 0;
static int ecode = 0;
static char popi_cfgfn[100]  = "popi.conf";     /* default */
static int opt_popicfg = 0;
static int ipraw_sockfd;
static pcap_t *pcapfp;
static char opt_filter[100];
static struct timeval start_tv;

static char *show_allpts(cprobe_t *);
static void get_popid_stat(cprobe_t *probe);
static void wait_to_finish(int);
static void usage(void);
static void show_rcvd(cprobe_t *);
static void count_icmpreplay(cprobe_t *, const char *);
static void process_statfeed(cprobe_t *, char *);
static int  channel_cmd(int fd, cbuf_t *cbuf, char *cmd, char *rbuf, char *ebuf);
static void punch_firewall(int);
static void refill_firewall();
static void send_round(cprobe_t *);
static void send_burst(cprobe_t *);
static void send_packet(int);
static void recv_packet();
static void finish(cprobe_t *);

void usage(void)
{
    printf(
"usage: popi [options] host\n"
" options:\n"
"  -h        show this help\n"
"  -b        number of bursts\n"
"  -r        number of rounds in a burst (default=1)\n"
"  -I        interval between bursts (uX for X microseconds, otherwise for seconds).\n"
"            When used in conjunction -e to setup a hole through the Netfilter, \n"
"            the interval should be no longer than 5min. Otherwise, the timer \n"
"            in Netfilter times out.\n"
"  -H hops   specify packet TTL range used to probe, eg. 1-16. (default is 64-64).\n"
"            for hop-by-hop mode, you can use -H 1-0 and let popi measure and determine\n"
"            the suitable maximum ttl.\n"
"  -t        packet type (pt1,pt2,pt3,...)\n"
"               6/80/8000s  : tcp, source port 80, dest. port 8000, with SYN flag\n"
"               17/80/8000  : udp, source port 80, dest. port 8000\n"
"               1/4000/8    : icmp, type 8 (echo request), id 4000\n"
"  -l len    packet length (include ip header) (default=1500)\n"
"  -m magic  magic number\n"
"  -nc       do not setup control channel\n"
"  -ns       popid do not send feedback receive statistic. (rarely used)\n"
"  -e        send TCP packets without SYN flag in TCP connection emulation mode.\n"
"            (useful for PlanetLab nodes)\n"
"  -d        let popid dump packet\n"
"  -f file   suffix of popid's dump file\n"
"  -w file   dump received packets (for debug purpose)\n"
"  -o file   save probe result\n"
);
    exit(0);
}

char *
show_allpts(cprobe_t *cprobe)
{
    int i;
    pktype_t *pt;
    static char buf[255];

    buf[0] = '\0';
    for (i = 0; i < cprobe0.nsendpts; ++i) {
	pt = &cprobe->sendpts[i];
	if (i > 0)
	    strcat(buf, " ");
	strcat(buf, ptstr(pt));
	if (pt->protocol == IPPROTO_TCP && (pt->thflags & TCP_FLAG_SYN))
	    strcat(buf, "/s");
    }
    return buf;
}

void 
process_statfeed(cprobe_t *cprobe, char *buf)
{
    /* max buf len is 1500 */
    static char rcvbuf[MAX_STATFEED_LEN*2];
    char *s, *p0 = buf, *p1;
    int ir, ipkt, ipt;

    if (cprobe->dumpfd >= 0)
	sprintf(rcvbuf, "statfeed");
    do {
	s = strchr(p0, ' ');
	if (s) *s = '\0';
	p1 = strchr(p0, ',');
	*p1 = '\0';
	ir   = atoi(p0);
	ipkt = atoi(p1+1);
	if (s)
	    p0 = s+1;
	else
	    p0 = NULL;
	ipt = cprobe->sndpkts[ir%cprobe->nrh][ipkt];
	cprobe->nrcvd[ir/(cprobe->nr*(cprobe->end_ttl-cprobe->start_ttl+1))][ipt] += 1;
	cprobe->nrcvd_total[ipt] += 1;
	if (cprobe->dumpfd >= 0)
	    sprintf(rcvbuf + strlen(rcvbuf), " %d,%d,%d", ipt, ir, ipkt);
    } while (p0);
    if (cprobe->dumpfd >= 0)
	dump_meta(cprobe->dumpfd, rcvbuf);
}

void 
count_icmpreply(cprobe_t *cprobe, const char *pkt)
{
    struct iphdr *iph = (struct iphdr *)pkt;
    struct icmphdr *icmph = (struct icmphdr *)(pkt + 20);
    struct iphdr *oiph = (struct iphdr *)(pkt + 28);
    u_int16_t oipid;
    sndpkt_t *pspkt;

    if (icmph->type != ICMP_TIME_EXCEEDED || icmph->code != ICMP_EXC_TTL)
	return;
    pspkt = &cprobe->spkts[ntohs(oiph->id)];
    if (!pspkt->sent)
	return;
    cprobe->nicmperr[pspkt->ttl - cprobe->start_ttl][pspkt->ipt]++;
    pspkt->sent = 0;
    return;
}

void 
show_rcvd(cprobe_t *cprobe)
{
    int ttl, i;

    if (cprobe->end_ttl > cprobe->start_ttl) {
	printf("\n");
	for (ttl = cprobe->start_ttl; ttl <= cprobe->end_ttl; ++ttl) {
	    printf("hop %2d:\t", ttl);
	    for (i = 0; i < cprobe->nsendpts; ++i)
		printf("%4d", cprobe->nicmperr[ttl-cprobe->start_ttl][i]);
	    printf("\n");
	}
	if (cprobe->statfeed) {
	    printf("popid :\t");
	    for (i = 0; i < cprobe->nsendpts; ++i)
		printf("%4d", cprobe->nrcvd_total[i]);
	    printf("\n");
	}
    } else {
	if (cprobe->statfeed) {
	    printf("ib=%d popid:\t", cprobe->iburst-1);
	    for (i = 0; i < cprobe->nsendpts; ++i)
		printf("%4d", cprobe->nrcvd[cprobe->iburst-1][i]);
	    printf("\n");
	}
    }
}

int
channel_cmd(int fd, cbuf_t *cbuf, char *cmd, char *rbuf, char *ebuf)
{
    char pbuf[MAX_STATFEED_LEN], *p;
    ssize_t len;
    int rcode;

    if (send_control_cmd(fd, cmd) < 0) {
	sprintf(ebuf, "write error");
	return -1;
    }
 recv:
    if ((len = readline_cbuf(fd, cbuf, pbuf)) < 0) {
	sprintf(ebuf, "recvline_cbuf error");
	return -1;
    }
    
    if (opt_verbose)
	dbg_msg("option recv: %dbytes  %s", strlen(pbuf), pbuf);
    p = strchr(pbuf, ' ');
    *p = '\0';
    rcode = atoi(pbuf);
    switch (rcode) {
    case 400:             /* stat feedback */
	process_statfeed(&cprobe0, p+1);
	goto recv;
    case 100:
	if (rbuf)
	    strncpy(rbuf, p+1, 255);
	return 0;
    default:
	if (ebuf)
	    strncpy(ebuf, p+1, 255);
    }
    return -1;
}

void
get_popid_stat(cprobe_t *cprobe)
{
    char buf[255], rbuf[256], ebuf[256];
#if 0
    struct pcap_stat ps;
#endif

    /* get receive stat */
    if (cprobe->iburst > 0 && cprobe->statfeed)
	if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, "stat get", rbuf, ebuf) < 0)
	    err_quit("stat get error", ebuf);
#if 0
    /* send pcap stat */
    if (cprobe->sdump) {
    	pcap_stats(pcapfp, &ps);
	sprintf(buf, "meta send_pcapstat %d %d", ps.ps_recv, ps.ps_drop);
	channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, buf, rbuf, ebuf);
    }
#endif
    /* get pcap stat */
    if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, "pcapstat dump", rbuf, ebuf) < 0)
	err_quit("send pcapstat dump failed %s", ebuf);
    if (cprobe->iburst > 0 && cprobe->dumpfd >= 0) 
	dump_meta(cprobe->dumpfd, rbuf);
}

/* 
 * send a round of packets
 */
void 
send_round(cprobe_t *cprobe)
{
    static char sndbuf[BUFSIZE];
    struct iphdr *iph;
    struct udphdr *uh;
    struct icmphdr *icmph;
    struct tcphdr *th;
    struct timeval curtv;
    struct pseudohdr *ph;
    int ipkt, ipt;
    struct sockaddr_in sin;
    rndseq_t *prndseq;
    pktype_t *psendpt;
    u_int16_t dlen = cprobe->pktlen - 20;
    datamx_t *pd = (datamx_t *)(sndbuf + 8 + 40);

    bzero((char *)&sin, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = cprobe->daddr;
    gettimeofday(&curtv, NULL);

    prndseq = create_rndseq(cprobe->nsendpts);
    bzero(pd, cprobe->pktlen);
    pd->hlen  = POPIHDRLEN;
    pd->magic = htons(cprobe->magic);
    pd->ver   = PD_VERSION;
    pd->round   = htons(cprobe->iround);
    pd->tv_sec  = htonl(curtv.tv_sec);
    pd->tv_usec = htonl(curtv.tv_usec);
    for (ipkt = 0; ipkt < cprobe->nsendpts; ++ipkt) {
	ipt = fetch_from_rndseq(prndseq);
	if (cprobe->statfeed)
	    cprobe->sndpkts[cprobe->iround%cprobe->nrh][ipkt] = ipt;
	assert(ipt >= 0);
	psendpt = &cprobe->sendpts[ipt];
	pd->ck0    = local_ip + (htons(psendpt->sport_id) << 16) + htons(psendpt->dport_type);
	pd->ipkt   = ipkt;
	pd->check  = 0;
	pd->check  = in_cksum((unsigned short *)pd, POPIHDRLEN);
	switch (psendpt->protocol) {
	case IPPROTO_UDP:
	    /* construct udp header, no need to bzero */
	    uh = (struct udphdr *)((char *)pd - 8);
	    uh->check  = 0;
	    uh->source = htons(psendpt->sport_id);
	    uh->dest   = htons(psendpt->dport_type);
	    uh->len    = htons(dlen);
	    ph = (struct pseudohdr *)((char *)uh - 12);
	    ph->srcip  = local_ip;
	    ph->dstip  = cprobe->daddr;
	    ph->zero   = 0;
	    ph->prot   = IPPROTO_UDP;
	    ph->len    = htons(dlen);
	    /* PlanetLab Netfilter discards incoming 
	     * UDP,TCP,ICMP packet with error checksum. 
	     * We MUST send OK packets to planetlab popid. 
	     * However, Netfilter does not check outgoing
	     * packets. */ 
	    if (cprobe->pl_peer)
		uh->check = in_cksum((unsigned short *)ph, dlen + sizeof(struct pseudohdr));
	    else
		uh->check = in_cksum_err((unsigned short *)ph, dlen + sizeof(struct pseudohdr));
	    iph = (struct iphdr *)((char *)uh - 20);
	    break;
	case IPPROTO_TCP:
	    /* construct tcp header */
	    th = (struct tcphdr *)((char *)pd - 20);
	    bzero(th, sizeof(struct tcphdr));
	    th->source = htons(psendpt->sport_id);
	    th->dest   = htons(psendpt->dport_type);
	    th->doff   = 5;
	    th->window = htons(32768);
	    tcp_flag_byte(th) |= psendpt->thflags;
	    if (cprobe->tcpemulate && cprobe->tcp_establish[ipt]) {
		th->seq     = htonl(psendpt->th_seq + 1);
		th->ack_seq = htonl(psendpt->th_ack);
	    } else {
		th->seq     = htonl(psendpt->th_seq);       /* same for all SYN packets */
		th->ack_seq = htonl(cprobe->ack_seq++);
	    }
	    ph = (struct pseudohdr *)((char *)th - 12);
	    ph->srcip  = local_ip;
	    ph->dstip  = cprobe->daddr;
	    ph->zero   = 0;
	    ph->prot   = IPPROTO_TCP;
	    ph->len    = htons(dlen);
	    if (cprobe->pl_peer)
		th->check = in_cksum((unsigned short *)ph, dlen + sizeof(struct pseudohdr));
	    else
		th->check = in_cksum_err((unsigned short *)ph, dlen + sizeof(struct pseudohdr));
	    iph = (struct iphdr *)((char *)th - 20);
	    break;
	default:
	    icmph = (struct icmphdr *)((char *)pd - 8);
	    icmph->type = (unsigned char)psendpt->dport_type;
	    icmph->code = 0;
	    icmph->un.echo.id = htons(psendpt->sport_id);
	    icmph->un.echo.sequence = htons(cprobe->icmpseq++);
	    icmph->checksum = 0;
	    if (cprobe->pl_peer)
		icmph->checksum = in_cksum((unsigned short *)icmph, dlen);
	    else
		icmph->checksum = in_cksum_err((unsigned short *)icmph, dlen + sizeof(struct pseudohdr));
	    iph = (struct iphdr *)((char *)icmph - 20);
	}
	bzero((char *)iph, sizeof(struct iphdr));
	iph->ihl      = 5;
	iph->version  = 4;
	iph->tot_len  = htons(cprobe->pktlen);
	iph->id       = htons(cprobe->ipid);
	iph->frag_off = htonl(0x4000);
	iph->ttl      = cprobe->ttl;
	iph->protocol = psendpt->protocol;
	iph->daddr    = cprobe->daddr;
#if ((DEBUG) & (DEBUG_P))
	dbg_msg("send daddr=%s (p%u,s%u,d%u) len%d (%u,%u)\n", 
		GET_IPSTR(iph->daddr),
		psendpt->protocol, psendpt->sport_id, psendpt->dport_type,
		dlen, ntohs(pd->round), pd->ipkt);
#endif
    sendto:
	if (sendto(ipraw_sockfd, iph, cprobe->pktlen, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
	    if (errno == ENOBUFS || errno == EINTR) {
		goto sendto;
	    } else {
		err_ret("sendto %s (%u,%u,%u)", GET_IPSTR(iph->daddr), 
			psendpt->protocol, psendpt->sport_id, psendpt->dport_type);
		continue;
	    }
	}
	/* remember send packet by ipid */
	cprobe->spkts[cprobe->ipid].ttl = iph->ttl;
	cprobe->spkts[cprobe->ipid].ir  = cprobe->iround;
	cprobe->spkts[cprobe->ipid].ipkt = ipkt;
	cprobe->spkts[cprobe->ipid].ipt = ipt;
	cprobe->spkts[cprobe->ipid].sent = 1;
	/* ipid increment by one */
	if (++cprobe->ipid == 0) ++cprobe->ipid;
    }
}

/*
 * send a burst 
 */
void
send_burst(cprobe_t *cprobe)
{
    int i;
    u_int8_t ttl;

    for (ttl = cprobe->start_ttl; 
	 ttl <= cprobe->end_ttl; ++ttl) {
	cprobe->ttl = ttl;
	for (i = 0; i < cprobe->nr; ++i) {
	    send_round(cprobe);
	    cprobe->iround++;
	}
    }
}

void 
send_packet(int signal_id)
{
    char buf[500], rbuf[256], ebuf[256];
    struct pcap_stat ps;

    /* sending packet types */
    if (cprobe0.iburst == 0) {
	printf("packet types: %s\n", show_allpts(&cprobe0));
	sprintf(buf, "meta pktypes ");
	strcat(buf, show_allpts(&cprobe0));
	if (cprobe0.ctrlfd >= 0
	    && channel_cmd(cprobe0.ctrlfd, &cprobe0.cbuf, buf, NULL, NULL) < 0)
		err_quit("send punch meta failed.");
	if (cprobe0.dumpfd >= 0)
	    dump_meta(cprobe0.dumpfd, buf+5);
    }
    /* send and get pcap stat */
    if (cprobe0.ctrlfd >= 0) 
	get_popid_stat(&cprobe0);
    /* show received packet */
    if (cprobe0.iburst > 0)
	show_rcvd(&cprobe0);
    /* send one burst */
#ifdef DEBUG
    dbg_msg("iburst %d\n", cprobe0.iburst);
#endif
    send_burst(&cprobe0);
    cprobe0.iburst++;

    /* schedule next round */
    if (cprobe0.iburst >= cprobe0.nb) {
	signal(SIGALRM, wait_to_finish);
	alarm(2);
	return;
    }
    if (cprobe0.intvl || cprobe0.waitinusec) {
	if (!cprobe0.waitinusec)
	    alarm(cprobe0.intvl);
	else
	    setitimer(ITIMER_REAL, &cprobe0.usec_intvl, NULL);
    }
}

void
wait_to_finish(int signal_id)
{
    signal(SIGALRM, SIG_DFL);
    probe_finish = 1;
}

int
setup_control_channel(cprobe_t *cprobe)
{
    char cmd[255], rbuf[256], ebuf[256], *p;
    int i;
    char dipstr[20], sipstr[20];
    int rpkt_ttl;

    cprobe->ctrlfd = open_control_channel(cprobe->daddr, ctrlport, cprobe->spkt_ttl);
    if (cprobe->ctrlfd < 0)
	return -1;

    /* planetlab */
    sprintf(cmd, "planetlab %d", is_planetlab);
    if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, cmd, rbuf, ebuf) < 0)
	return -1;
    p = strchr(rbuf, ' ');
    cprobe->pl_peer = atoi(p+1);
    if (!cprobe->pl_peer) {
	tcp_csum_error = 1; udp_csum_error = 1; icmp_csum_error = 1;
    }
    /* probe ttl range */
    if (!cprobe->end_ttl) {
	if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, "rpkt_ttl", rbuf, ebuf) < 0)
	    return -1;
	rpkt_ttl = atoi(rbuf);
	if (rpkt_ttl < 0) {
	    dbg_msg("rpkt_ttl = %d\n", rpkt_ttl);
	    return -1;
	}
	cprobe->end_ttl = cprobe->spkt_ttl - rpkt_ttl + 1;
    }
    /* magic */
    sprintf(cmd, "magic %d", cprobe->magic);
    if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, cmd, rbuf, ebuf) < 0)
	err_quit("fail to set magic: %s", ebuf);
    /* server dump */
    if (cprobe->sdump 
	&& channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, "dump 4", rbuf, ebuf) < 0) {
	dbg_msg("fail to set server dump suffix: %s\n", ebuf);
	return -1;
    }
    /* send -b -N -l -I -H arguments */
    sprintf(cmd, "args saddr=%s daddr=%s magic=%d npt=%d nb=%d nr=%d pktlen=%d intvl=%u ttl=%u,%u", 
	    local_ip_str, GET_IPSTR(cprobe->daddr), cprobe->magic,
	    cprobe->nsendpts, cprobe->nb, cprobe->nr, cprobe->pktlen, 
	    cprobe->waitinusec?cprobe->usec_intvl.it_value.tv_usec:(cprobe->intvl*1000000),
	    cprobe->start_ttl, cprobe->end_ttl);
    if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, cmd, rbuf, ebuf) < 0) {
	dbg_msg("fail to set args: %s\n", ebuf);
	return -1;
    }
    /* tcpemulate */
    if (cprobe->tcpemulate
	&& channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, "tcpemulate", rbuf, ebuf) < 0) {
	dbg_msg("fail to negotiate tcpemulate: %s", ebuf);
	return -1;
    }
    /* statfeed */
    if (cprobe->statfeed) {
	if (channel_cmd(cprobe->ctrlfd, &cprobe->cbuf, "stat enable", rbuf, ebuf) < 0) {
	    dbg_msg("fail to negotiate stat: %s", ebuf);
	    return -1;
	}
	cprobe->nrh = 2*cprobe->nr;
	cprobe->sndpkts  = malloc(cprobe->nrh*sizeof(int*));
	cprobe->sndpkts_ = calloc(cprobe->nrh*cprobe->nsendpts, sizeof(int));
	for (i = 0; i < cprobe->nrh; ++i)
	    cprobe->sndpkts[i] = &cprobe->sndpkts_[i*cprobe->nsendpts];
	cprobe->nrcvd  = malloc(cprobe->nb*sizeof(int*));
	cprobe->nrcvd_ = calloc(cprobe->nb*cprobe->nsendpts, sizeof(int));
	for (i = 0; i < cprobe->nb; ++i)
	    cprobe->nrcvd[i] = &cprobe->nrcvd_[i*cprobe->nsendpts];
	cprobe->nrcvd_total = calloc(cprobe->nsendpts, sizeof(int));
    }
    return 0;
}

void
punch_firewall(int signal_id)
{
    static int npunch = 0;
    int i, j = 0;
    unsigned char sndbuf[100], cmd[500];
    pktype_t curpt, *pt;

    if (!npunch) {
	printf("punching firewall.");
    } else 
	printf(".");
    fflush(NULL);
    /* setup tcp connection */
    for (i = 0; i < cprobe0.nsendpts; ++i) {
	pt = &cprobe0.sendpts[i];
	if (pt->protocol != IPPROTO_TCP 
	    || cprobe0.tcp_establish[i])
	    continue;
	pt->th_seq = cprobe0.syn_seq;
	curpt = *pt;
	curpt.thflags = TCP_FLAG_SYN;
	prepare_tcp(&curpt, cprobe0.daddr, sndbuf+40, 0);
	send_pkt(ipraw_sockfd, sndbuf, 40);
	j++;
    }
    
    if (++npunch >= 3 || !j) {
	printf("\n");
	signal(SIGALRM, send_packet);
    }

    alarm(1);
}

void
refill_firewall()
{
    int i;
    unsigned char buf[100];
    pktype_t curpt, *pt;

    for (i = 0; i < cprobe0.nsendpts; ++i) {
	pt = &cprobe0.sendpts[i];
	/* send RST for TCP conntrack in ESTABLISH */
	if (pt->protocol != IPPROTO_TCP || !cprobe0.tcp_establish[i])
	    continue;
	curpt = *pt;
	curpt.thflags = (TCP_FLAG_RST | TCP_FLAG_ACK);  
	/* thseq of RST should be larger than maxseq sent so far */
	curpt.th_seq  += cprobe0.pktlen - 40 + 1;
	prepare_tcp(&curpt, cprobe0.daddr, buf+40, 0);
	if (send_pkt(ipraw_sockfd, buf, 40) < 0)
	    dbg_msg("fail to RST from localhost:%d to %s:%d\n", 
		    curpt.sport_id, GET_IPSTR(cprobe0.daddr), curpt.dport_type);
    }
}

void 
recv_packet()
{
    int j, pktlen, pfsock, maxrsockfd = 0, availnrsks;
    ssize_t nbytes;
    const unsigned char *pkt;
    struct pcap_pkthdr pcap_h;
    struct iphdr *iph;
    struct tcphdr *th;
    struct udphdr *uh;
    struct icmphdr *icmph;
    pktype_t *pt;
    u_int8_t protocol;
    u_int16_t dport_type, sport_id;
    fd_set sock_rset, allrset;
    cprobe_t *cprobe = &cprobe0;
    char pbuf[MAX_STATFEED_LEN];

    FD_ZERO(&sock_rset);
    FD_ZERO(&allrset);
    pfsock = pcap_fileno(pcapfp);
    FD_SET(pfsock, &allrset);
    maxrsockfd = pfsock;
    if (cprobe->ctrlfd >= 0) {
	FD_SET(cprobe->ctrlfd, &allrset);
	if (cprobe->ctrlfd > maxrsockfd)
	    maxrsockfd = cprobe->ctrlfd;
    }

    while (1) {
	if (probe_finish)
	    return;
	sock_rset = allrset;
	if ((availnrsks = select(maxrsockfd + 1, &sock_rset, NULL, NULL, NULL)) <= 0) {
	    if (availnrsks == 0)
		continue;
	    if (errno == EINTR)
		;
	    else
		err_ret("select");
	    continue;
	}
	if (FD_ISSET(pfsock, &sock_rset)) {
	    pkt = pcap_next(pcapfp, &pcap_h);
	    pkt += 14;
	    iph = (struct iphdr *)pkt;
	    pktlen = pcap_h.len - 14;
	    /* ignore outgoing packets */
	    if (iph->saddr == local_ip)
		continue;
	    protocol = iph->protocol;
	    switch (protocol) {
	    case IPPROTO_TCP:
		th = (struct tcphdr *)(iph + 1);
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("[%s] saddr=%s (p%u,s%u,d%u) thflags%d len%d (%u,%u)\n", 
			__func__,
			GET_IPSTR(iph->saddr),
			iph->protocol, ntohs(th->source), ntohs(th->dest),
			tcp_flag_byte(th), pktlen);
#endif
		break;
	    case IPPROTO_UDP:
		uh = (struct udphdr *)(iph + 1);
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("[%s] saddr=%s (p%u,s%u,d%u) len%d (%u,%u)\n", 
			__func__,
			GET_IPSTR(iph->saddr),
			iph->protocol, ntohs(uh->source), ntohs(uh->dest), pktlen);
#endif
		break;
	    case IPPROTO_ICMP:
		icmph = (struct icmphdr *)(iph + 1);
#if ((DEBUG) & (DEBUG_P))
		dbg_msg("[%s] saddr=%s (p%u,s%u,d%u) len%d\n", 
			__func__,
			GET_IPSTR(iph->saddr),
			iph->protocol, ntohs(icmph->un.echo.id), icmph->type, pktlen);
#endif
		break;
	    default:
		continue;
	    }
	    
	    /* process SYN/ACK for tcpemulation mode */
	    if (cprobe->tcpemulate 
		&& iph->saddr == cprobe->daddr && protocol == IPPROTO_TCP
		&& th->syn && th->ack && ntohs(iph->tot_len) == 40) {
		dport_type = ntohs(th->source);
		sport_id   = ntohs(th->dest);
		for (j = 0; j < cprobe->nsendpts; ++j) {
		    pt = &cprobe->sendpts[j];
		    if (protocol == pt->protocol
			&& dport_type == pt->dport_type
			&& sport_id   == pt->sport_id  )
			break;
		}
		/* not the packet we've sent */
		if (j == cprobe->nsendpts)
		    continue;
		/* update tcp_establish, thflags and tcp_ack */
		cprobe->tcp_establish[j] = 1;
		pt->thflags = TCP_FLAG_ACK;
		pt->th_ack  = ntohl(th->seq) + 1;
	    }

	    if (protocol == IPPROTO_ICMP || iph->saddr == cprobe->daddr) {
		if (cprobe->dumpfd >= 0) {
		    /* dump all received packets */
		    if (dump_packet(cprobe->dumpfd, pcap_h.ts, pkt, pktlen) < 0)
			err_quit("dump received packets");
		}
		if (protocol == IPPROTO_ICMP)
		    count_icmpreply(cprobe, pkt);
	    }
	    continue;
	}
    
	/* process control channel */
	if (cprobe->ctrlfd >= 0 && FD_ISSET(cprobe->ctrlfd, &sock_rset)) {
	    nbytes = readline_cbuf(cprobe->ctrlfd, &cprobe->cbuf, pbuf);
	    if (nbytes <= 0) {
		dbg_msg("ctrl channel closed, exiting...\n");
		probe_finish = 1;
		ecode = 2;
		continue;
	    } else {
		char *p;
		int rcode;
		p = strchr(pbuf, ' ');
		*p = '\0';
		rcode = atoi(pbuf);
		switch (rcode) {
		case 400:             /* stat feedback */
		    process_statfeed(cprobe, p+1);
		    break;
		case 500:             /* dump error */
		    err_quit("receiver dump error: %s", p+1);
		default:
		    err_ret("strange. receive command response. %s", p+1);
		}
	    }
	}
    }
}

/* print result */
void
finish(cprobe_t *cprobe)
{
    int i, j;
    if (cprobe->ctrlfd >= 0)
	get_popid_stat(&cprobe0);
    show_rcvd(&cprobe0);
    if (cprobe->ofp) {
	fprintf(cprobe->ofp, "args nr=%d nb=%d npt=%d\n", 
		cprobe->nr, cprobe->nb, cprobe->nsendpts);
	fprintf(cprobe->ofp, "pktypes");
	for (i = 0; i < cprobe->nsendpts; ++i)
	    fprintf(cprobe->ofp, " %s", ptstr(&cprobe->sendpts[i]));
	fprintf(cprobe->ofp, "\n");
	for (j = 0; j < cprobe->nb; ++j) {
	    fprintf(cprobe->ofp, "popid ib=%d", j);
	    for (i = 0; i < cprobe->nsendpts; ++i)
		fprintf(cprobe->ofp, " %d", cprobe->nrcvd[j][i]);
	    fprintf(cprobe->ofp, "\n");
	}
    }
}

int 
main(int argc, char *argv[])
{
    char line[255], *pstr, iface[10] = "eth0";
    int c, i;
    struct timeval curtv;

    strncpy(program_name, basename(argv[0]), 20);
    gettimeofday(&start_tv, NULL);
    srand(start_tv.tv_sec);
    assert(sizeof(datamx_t) == 30);

    cprobe0.ctrlchannel = 1;
    cprobe0.statfeed = 1;
    cprobe0.start_ttl = 64;
    cprobe0.end_ttl  = 64;
    cprobe0.ipid = 1;
    cprobe0.nr = 1;
    cprobe0.dumpfd = -1;
    cprobe0.ctrlfd = -1;
    cprobe0.spkt_ttl = 64;
    while ((c = getopt(argc, argv, "b:c:dehH:I:l:m:n:o:p:r:t:vVw:i:")) != EOF) {
	switch(c) {
	case 'b':
	    cprobe0.nb = atoi(optarg);                   	    /* number of bursts */
	    break;
	case 'c':
	    if (optarg[0] == 'c') {
		strncpy(popi_cfgfn, optarg+1, 100);                   /* popi.conf */
		opt_popicfg = 1;
	    } else {
		err_quit("unknown option!");
	    }
	    break;
	case 'd':
	    cprobe0.sdump = 1;
	    break;
	case 'e':
	    cprobe0.tcpemulate = 1;
	    break;
	case 'h':
	    usage();
	    break;
	case 'I':
	    /* interval between two burst */
            if (optarg[0] == 'u') {
                cprobe0.waitinusec = 1;
                cprobe0.usec_intvl.it_value.tv_sec = 0;
                cprobe0.usec_intvl.it_interval.tv_sec = 0;
                cprobe0.usec_intvl.it_value.tv_usec =
                    cprobe0.usec_intvl.it_interval.tv_usec = atol(optarg+1);
            } else {
                cprobe0.intvl = atoi(optarg);
            }
	    break;
	case 'l':
	    cprobe0.pktlen = atoi(optarg);
	    break;
	case 'H':
	    cprobe0.pmode  = 1;
	    pstr = strchr(optarg, '-');
	    if (!pstr)
		err_quit("-H: start_ttl-end_ttl");
	    *pstr = '\0';
	    cprobe0.start_ttl = atoi(optarg);
	    cprobe0.end_ttl   = atoi(pstr+1);
	    if (cprobe0.end_ttl != 0 && cprobe0.start_ttl > cprobe0.end_ttl)
		err_quit("-H: start_ttl should be less than end_ttl");
	    break;
	case 'm':
	    cprobe0.magic  = atoi(optarg);
	    break;
	case 'n':
	    if (optarg[0] == 's')
		cprobe0.statfeed = 0;
	    else if (optarg[0] == 'c') {
		cprobe0.ctrlchannel = 0;
		cprobe0.statfeed = 0;
	    } else
		err_quit("unknown -n%s option!", optarg);
	    break;
	case 'o':
	    strncpy(cprobe0.ofname, optarg, 255);
	    break;
	case 'p':
	    ctrlport   = atoi(optarg);                       	    /* server control port */
	    break;
	case 'r':
	    cprobe0.nr = atoi(optarg);
	    break;
	case 't':
	    if ((cprobe0.nsendpts = create_pktypes(cprobe0.sendpts, MAX_RAWPKTS, optarg)) < 0)
		err_quit("unknown packet types!");
	    break;
	case 'v':
	    opt_verbose++;
	    break;
	case 'V':
	    dbg_msg("%s\n", rev);
	    exit(0);
	case 'w':
	    strncpy(cprobe0.dumpfname, optarg, 255);
	    break;
	case 'i':
	    strncpy(iface, optarg, 10);
	    break;
	default:
	    err_quit("unknown %c option!", c);
	}
    }

#if 0
    if (opt_popicfg) {
	if (read_popi_cfg(popi_cfgfn) == -1)
	    err_quit("read %s error.", popi_cfgfn);
    }
#endif
    /* destionation */
    if (optind == argc)
	err_quit("please specify destination ip.");
    else 
	if (!inet_aton(argv[optind], (struct in_addr *)&cprobe0.daddr))
	    err_quit("wrong destination ip %s", argv[optind]);
    if (cprobe0.nr == 0) err_quit("please use -r to specify nr >= 1.");
    if (cprobe0.nb == 0) err_quit("please use -b to specify nb >= 1");
    if (cprobe0.ctrlchannel == 0 &&
	(cprobe0.tcpemulate == 1 || cprobe0.sdump == 1 || cprobe0.statfeed == 1))
	err_quit("option -e and -s conflict with -nc");
    if (cprobe0.magic == 0) cprobe0.magic = rand();
    if (cprobe0.intvl == 0) cprobe0.intvl = 1;
    if (cprobe0.pktlen == 0) cprobe0.pktlen = 1500;
    if (cprobe0.ttl == 0) cprobe0.ttl = 64;
    if (cprobe0.tcpemulate) {
	for (i = 0; i < cprobe0.nsendpts; ++i)
	    if (cprobe0.sendpts[i].protocol == IPPROTO_TCP)
		cprobe0.sendpts[i].thflags = TCP_FLAG_SYN;
    }
#ifdef PlanetLab
    else {
	for (i = 0; i < cprobe0.nsendpts; ++i)
	    if (cprobe0.sendpts[i].protocol == IPPROTO_TCP 
		&& !(cprobe0.sendpts[i].thflags & TCP_FLAG_SYN))
		err_quit("cannot send TCP %s without SYN", ptstr(&cprobe0.sendpts[i]));
    }
#endif
    /* get local ip */
    if (get_local_ip(local_ip_str, &local_ip, &local_netmask, iface) == -1)
	err_quit("no local_ip found");
    /* binding ports */
    if (cprobe0.nsendpts == 0) 
	err_quit("no rawpkts to send.");
#ifdef PlanetLab
    else {
	int j;
	i = 0;
	while (i < cprobe0.nsendpts) {
	    if (bind_port(cprobe0.sendpts[i].protocol, cprobe0.sendpts[i].sport_id) < 0) {
		err_msg("%s cannot be bond", ptstr(&cprobe0.sendpts[i]));
		for (j = i+1; j < cprobe0.nr; ++j)
		    cprobe0.sendpts[j-1] = cprobe0.sendpts[j];
		cprobe0.nsendpts--;
	    } else 
		i++;
	}
	if (cprobe0.nsendpts == 0) err_quit("no rawpkts to send.");
    }
#endif
    /* open pcap and send raw socket */
    if (cprobe0.ctrlchannel) 
	sprintf(opt_filter, "!tcp port %d && !src host %s", ctrlport, local_ip_str);
    pcapfp = open_pcap(iface, 65535, opt_filter);
    ipraw_sockfd = open_rawsend();
    set_sock_sndbuf(ipraw_sockfd, 30000);
    /* open output result */
    if (cprobe0.ofname[0] && !(cprobe0.ofp = fopen(cprobe0.ofname, "w")))
	err_sys("open output file failed");
    /* open dump */
    if (cprobe0.dumpfname[0]) {
	char meta[255], errbuf[255];
	if ((cprobe0.dumpfd = open_dump(cprobe0.dumpfname, 100, 4, errbuf)) < 0)
	    err_quit("open dump file failed: %s", errbuf);
	/* send -b -N -l -I -H arguments */
	sprintf(meta, "time %u", start_tv.tv_sec);
	dump_meta(cprobe0.dumpfd, meta);
	sprintf(meta, "args saddr=%s daddr=%s magic=%d npt=%d nb=%d nr=%d pktlen=%d intvl=%u ttl=%u,%u", 
		local_ip_str, GET_IPSTR(cprobe0.daddr), cprobe0.magic,
		cprobe0.nsendpts, cprobe0.nb, cprobe0.nr, cprobe0.pktlen, 
		cprobe0.waitinusec?cprobe0.usec_intvl.it_value.tv_usec:(cprobe0.intvl*1000000),
		cprobe0.start_ttl, cprobe0.end_ttl);
	dump_meta(cprobe0.dumpfd, meta);
    }
    /* setup the control channel */
    if (cprobe0.ctrlchannel)
	if (setup_control_channel(&cprobe0) < 0)
	    err_quit("fail to setup control channel");
    /* malloc send */
    cprobe0.nicmperr  = malloc((cprobe0.end_ttl-cprobe0.start_ttl+1)*sizeof(int*));
    cprobe0.nicmperr_ = calloc((cprobe0.end_ttl-cprobe0.start_ttl+1)*cprobe0.nsendpts, sizeof(int));
    for (i = 0; i < cprobe0.end_ttl-cprobe0.start_ttl+1; ++i)
	cprobe0.nicmperr[i] = &cprobe0.nicmperr_[i*cprobe0.nsendpts];

    printf("from %s to %s, magic number %d, %d packet types\n", 
	    local_ip_str, 
	    GET_IPSTR(cprobe0.daddr),
	    cprobe0.magic, cprobe0.nsendpts);
    printf("ttl range %d - %d\n", cprobe0.start_ttl, cprobe0.end_ttl);
    /* set SIGINT/TERM/ALRM */
    // Signal(SIGINT, sigexit);
    // Signal(SIGTERM, sigexit);
    if (cprobe0.tcpemulate) {
	cprobe0.syn_seq = (start_tv.tv_sec << 16 | start_tv.tv_usec);
	signal(SIGALRM, punch_firewall);
    } else
	signal(SIGALRM, send_packet);

    /* emulation mode: punch_firewall -> send_packet
       non-emu   mode: send_packet */
    alarm(1);

    recv_packet();

    finish(&cprobe0);

    /* refill the hole in firewall */
    if (cprobe0.tcpemulate)
	refill_firewall();

    return(ecode);
}
