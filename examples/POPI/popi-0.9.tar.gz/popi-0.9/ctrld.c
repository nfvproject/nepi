/* inet_aton */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pcap.h>
/* fcntl() */
#include <unistd.h>
#include <fcntl.h>
/* free() */
#include <stdlib.h>

#include "common.h"
#include "send.h"
#include "popid.h"
#include "utils.h"
#include "errfun.h"
#include "dump.h"
#include "ctrld.h"

/* 
 * open ctrl listen socket/set to non-blocking
 * RETURN  fd
 *   always success, abort if failed.
 */
int listen_control_channel(unsigned short port)
{
    int fd, val;
    struct sockaddr_in sin;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	err_sys("cannot open ctrlfd");
    }

    bzero(&sin, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = htonl(INADDR_ANY);
    sin.sin_port = htons(port);
    
    if (bind(fd, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
	err_ret("[%s] : cannot bind ctrlfd %d", __func__, port);
	return -1;
    }

    if (listen(fd, 10) < 0) {
	err_ret("[%s] : cannot listen ctrlfd", __func__);
	return -1;
    }

    return (fd);
}

/* 
 * accept new control connection, 
 * RETURN fd
 */
int 
accept_conn(int listenfd, struct sockaddr_in *from)
{
    socklen_t len;
    int fd, val;

    len = sizeof(struct sockaddr_in);
    if ((fd = accept(listenfd, (struct sockaddr *)from, &len)) == -1) {
	err_ret("[%s] : accept error", __func__);
	return -1;
    }

#ifdef DEBUG
    dbg_msg ("accept ctrl tcp from %s\n", inet_ntoa(from->sin_addr));
#endif
    return(fd);
}

int
send_control_rsp(int fd, char *cmd)
{
    static char eof[] = "\n";
    struct iovec cmdv[2];

    cmdv[0].iov_base = cmd;
    cmdv[0].iov_len  = strlen(cmd);
    cmdv[1].iov_base = eof;
    cmdv[1].iov_len  = 1;

#if ((DEBUG) & (DEBUG_C))
    dbg_msg("[%s] rsp:\"%s\"\n", __func__, cmd);
#endif
 send:
    if (writev(fd, cmdv, 2) < 0) {
	if (errno == EINTR)
	    goto send;
	else {
	    err_ret("[%s], errno %d", __func__, errno);
	    return -1;
	}
    }
    return 0;
}

/*
 * handle ctrl cmd from socket fd
 * RETURN
 *   0     on success/or cmd ignored
 *  -1     read socket error
 * ============================================
 * commands:
 * =======+================================+============================
 *   cmd  |  options                       | funcs
 * -------+--------------------------------+----------------------------
 *  show  |  ver                           | 
 *        |  md5                           | show round
 *        |  probe                         | 
 * -------+--------------------------------+----------------------------       
 *  stat  |                                | setup stat feedback channel
 * -------+--------------------------------+----------------------------
 */
int 
handle_ctrlcmd(probe_t *probe, char *pbuf)
{
    static char sndbuf[1000] = "", errbuf[255];
    char **argv, *line;
    int argc, i;

    line = strdup(pbuf);
    argv = split_string(line, &argc);
    if (argc == 0)
	return 0;

    if (strcmp(argv[0], "show") == 0) {
	if (strcmp(argv[1], "ver") == 0) {
	    sprintf(sndbuf, "100 %s", rev);
	    goto respond;
	}
    } else if (strcmp(argv[0], "stat") == 0) {
	if (strcmp(argv[1], "enable") == 0) {
	    probe->statfeed = 1;
	    dbg_msg("feedback statistics\n");
	    if (probe->nrpts == 0 || probe->nr == 0 || probe->nb == 0) {
		sprintf(sndbuf, "200 nr,nrpts,nb is zero");
		goto respond;
	    }
	    probe->rcvpkts_total = probe->nrpts*probe->nr*2;
#ifdef DEBUG
	    dbg_msg("sizeof(rcvpkt_t)=%d total %d\n", sizeof(rcvpkt_t), probe->rcvpkts_total);
#endif
	    if (!(probe->rcvpkts = (rcvpkt_t *)calloc(probe->rcvpkts_total, sizeof(rcvpkt_t)))) {
		sprintf(sndbuf, "200 calloc failed");
		goto respond;
	    }
	    // memset(probe->rcvpkts, 0, sizeof(rcvpkt_t)*probe->rcvpkts_total);
	    probe->rcvpkts_head = probe->rcvpkts_tail = probe->rcvpkts_missed = 0;
	    goto ok;
	} else if (strcmp(argv[1], "get") == 0) {
	    send_statfeed(probe);
	    goto ok;
	}
    } else if (strcmp(argv[0], "tcpemulate") == 0) {
	probe->tcpemulate = 1;
#ifdef DEBUG
	dbg_msg("use tcpemulate mode to %s\n", GET_IPSTR(probe->saddr));
#endif
	goto ok;
    } else if (strcmp(argv[0], "magic") == 0) {
	probe->magic = htons(atoi(argv[1]));
#ifdef DEBUG
	dbg_msg("magic = %d\n", ntohs(probe->magic));
#endif
	goto ok;
    } else if (strcmp(argv[0], "dump") == 0) {
	char meta[255], filename[100];
	char *saddr_str = GET_IPSTR(probe->saddr);
	u_int8_t mver = atoi(argv[1]);
	struct timeval curtv;
	gettimeofday(&curtv, NULL);
	if (argc >= 3)
	    sprintf(probe->dumpfnpfx, "%s_%s_%u_%us_%s", 
		    saddr_str, local_ip_str, ntohs(probe->magic), curtv.tv_sec, argv[2]);
	else
	    sprintf(probe->dumpfnpfx, "%s_%s_%u_%us", 
		    saddr_str, local_ip_str, ntohs(probe->magic), curtv.tv_sec);
	sprintf(filename, "%s.dmp", probe->dumpfnpfx);
	if ((probe->dumpfd = open_dump(filename, PKTDMPLEN, mver, errbuf)) < 0) {
#ifdef DEBUG
	    dbg_msg("open %s failed: %s", filename, errbuf);
#endif
	    sprintf(sndbuf, "200 %s", errbuf);
	    goto respond;
	} else {
	    sprintf(meta, "time %u", curtv.tv_sec);
	    dump_meta(probe->dumpfd, meta);
#ifdef DEBUG
	    dbg_msg("%s opened", filename);
#endif
	    goto ok;
	}
    } else if (strcmp(argv[0], "pcapstat") == 0) {
	struct pcap_stat ps;
	char filename[100];
	FILE *metafp;
	get_pcap_stats(&ps);
	if (strcmp(argv[1], "clear") == 0) {
	    dbg_msg("pcapstat clear ok ps_recv %d ps_drop %d\n", ps.ps_recv, ps.ps_drop);
	    sprintf(sndbuf, "100 pcapstat clear ok %d %d", ps.ps_recv, ps.ps_drop);
	} else if (strcmp(argv[1], "dump") == 0) {
	    sprintf(sndbuf, "100 pcapstat %d %d", ps.ps_recv, ps.ps_drop);
	    if (probe->dumpfd >= 0)
		dump_meta(probe->dumpfd, sndbuf+4);
	}
	goto respond;
    } else if (strcmp(argv[0], "args") == 0) {
	char *pstr;
	for (i = 1; i < argc; ++i) {
	    pstr = strchr(argv[i], '=');
	    *pstr = '\0';
	    if (strcmp(argv[i], "nr") == 0)
		probe->nr = atoi(pstr+1);
	    else if (strcmp(argv[i], "intvl") == 0)
		probe->intvl = atoi(pstr+1);
	    else if (strcmp(argv[i], "nb") == 0)
		probe->nb = atoi(pstr+1);
	    else if (strcmp(argv[i], "npt") == 0)
		probe->nrpts = atoi(pstr+1);
	}
	if (probe->dumpfd >= 0)
	    dump_meta(probe->dumpfd, pbuf);
	goto ok;
    } else if (strcmp(argv[0], "meta") == 0) {
	if (probe->dumpfd >= 0)
	    dump_meta(probe->dumpfd, pbuf+5);
	goto ok;
    } else if (strcmp(argv[0], "planetlab") == 0) {
	probe->pl_peer = atoi(argv[1]);
	sprintf(sndbuf, "100 planetlab %d", is_planetlab_popid());
	if (!probe->pl_peer) {
	    tcp_csum_error = udp_csum_error = icmp_csum_error = 1;
	}
	goto respond;
    } else if (strcmp(argv[0], "rpkt_ttl") == 0) {
	sprintf(sndbuf, "100 %d", probe->rpkt_ttl);
	goto respond;
    } else {
	dbg_msg("'%s' not understand\n", pbuf);
	sprintf(sndbuf, "200 unknown command");
	goto respond;
    }
 ok:
    sprintf(sndbuf, "100 ok");
 respond:
    send_control_rsp(probe->ctrlfd, sndbuf);
    free(line);
    return 0;
}
