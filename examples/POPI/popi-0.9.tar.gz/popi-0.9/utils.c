#include <sys/types.h>
/* recvfrom */
#include <sys/socket.h>
/* strtok() */
#include <string.h>
/* rand() */
#include <stdlib.h>
/* errno */
#include <errno.h>

#include "common.h"
#include "errfun.h"
#include "utils.h"

u_int16_t
in_cksum(u_int16_t *addr, int len)
{
    int nleft = len;
    int sum = 0;
    u_int16_t *w = addr;
    u_int16_t answer = 0;

    while (nleft > 1) {
	sum += *w++;
	nleft -= 2;
    }

    if (nleft == 1) {
	*(u_int16_t *) (&answer) = *(u_int8_t *)w;
	sum += answer;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return(answer);
}

u_int16_t
in_cksum_err(u_int16_t *addr, int len)
{
    int nleft = len;
    int sum = 0;
    u_int16_t *w = addr;
    u_int16_t answer = 0;

    while (nleft > 1) {
	sum += *w++;
	nleft -= 2;
    }

    if (nleft == 1) {
	*(u_int16_t *) (&answer) = *(u_int8_t *)w;
	sum += answer;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    answer++;
    if (!answer) answer++;
    return(answer);
}

/* split string by 'space' */
char **
split_string(char *str, int *argc)
{
    static char *argv[10];
    int n = 0;
    argv[n++] = strtok(str, " ");
    while ((argv[n] = strtok(NULL, " ")))
	++n;
    *argc = n;
    return (argv);
}

ssize_t
readline_cbuf(int fd, cbuf_t *pcbuf, char *rbuf)
{
    int i, head;
    ssize_t len;

    while(1) {
	/* readline from cbuf first */
	for (i = pcbuf->head; i < pcbuf->tail; ++i) {
	    if (pcbuf->buf[i] == '\n') {
		pcbuf->buf[i] = '\0';
		head = pcbuf->head;
		pcbuf->head = i + 1;
#if ((DEBUG) & (DEBUG_C))
		dbg_msg("[%s] line[%d,%d)=\"%s\"\n", __func__, head, pcbuf->head, pcbuf->buf+head);
#endif
		strcpy(rbuf, pcbuf->buf+head);
		/* update cbuf */
		if (pcbuf->tail - pcbuf->head > 0)
		    memmove(pcbuf->buf, pcbuf->buf+pcbuf->head, pcbuf->tail - pcbuf->head);
		pcbuf->tail -= pcbuf->head;
		pcbuf->head = 0;
		return (strlen(rbuf));
	    }
	}
    recv:
	len = recvfrom(fd, pcbuf->buf + pcbuf->tail, CRCVBUF_LEN - pcbuf->tail, 0, NULL, NULL);
	if (len <= 0) {
	    if (len < 0) {
		if (errno == EINTR)
		    goto recv;
		else
		    err_ret("[%s]", __func__);
	    }
	    return len;
	}
	pcbuf->tail += len;
    }
    return -1;
}

rndseq_t *create_rndseq(int n)
{
    static rndseq_t rndseq;
    int i = 0; 
    if (n >= MAX_RNDSEQ)
	return NULL;
    for (i = 0; i < n; ++i)
	rndseq.d[i] = i;
    rndseq.n = n;
    return(&rndseq);
}

int fetch_from_rndseq(rndseq_t *rndseq)
{
    int i, k, val;
    if (rndseq->n == 0)
	return -1;
    k = rand() % rndseq->n;
    val = rndseq->d[k];
    for (i = k+1; i < rndseq->n; ++i)
	rndseq->d[i-1] = rndseq->d[i];
    rndseq->n--;
    return val;
}
