/* getopt */
#include <unistd.h>
#include <stdio.h>
/* exit() */
#include <stdlib.h>
/* inet_aton */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
/* memset() */
#include <string.h>

#include "socket.h"
#include "send.h"
#include "errfun.h"

void usage(void)
{
    printf(
"usage: tcpsend [options] destination\n"
"  -t       packet types, proto/sport/dport/thflags,proto/id/type\n"
);
}

u_int32_t local_ip;

int main(int argc, char **argv)
{
    int ssockfd, i, c;
    char buf[2048], *pkt, local_ip_str[20];
    u_int32_t dip, local_netmask;
    int ntype = 0;
    pktype_t pts[20];

    while ((c = getopt(argc, argv, "t:")) != EOF) {
	switch(c) {
	case 't':
	    ntype = create_pktypes(pts, 20, optarg);
	    if (ntype < 0)
		err_quit("ntype < 0: %d", ntype);
	    break;
	default:
	    err_msg("invalid option");
	    usage();
	    exit(1);
	}
    }

    if (ntype == 0) {
	usage();
	exit(1);
    }

    if (get_local_ip(local_ip_str, &local_ip, &local_netmask, "eth0") == -1)
        err_quit("no local_ip found");
    dbg_msg("local IP %s\n", local_ip_str);

    if (optind >= argc) {
	usage();
	exit(1);
    }
    inet_aton(argv[optind], (struct in_addr *)&dip);

    ssockfd = open_rawsend();
#ifdef PlanetLab
    for (i = 0; i < ntype; ++i)
	if (bind_port(pts[i].protocol, pts[i].sport_id) < 0)
	    exit(1);
#endif
    
    for (i = 0; i < ntype; ++i) {
	memset(buf, 0, 2048);
	if (pts[i].protocol == IPPROTO_TCP) {
	    pkt = prepare_tcp(&pts[i], dip, buf+40, 100);
	    if (send_pkt(ssockfd, pkt, (buf+40-pkt)+100) < 0)
		printf("send error\n");
	} else if (pts[i].protocol == IPPROTO_UDP) {
	    pkt = prepare_udp(&pts[i], dip, buf+40, 100);
	    if (send_pkt(ssockfd, pkt, (buf+40-pkt)+100) < 0)
		printf("send error\n");
	} else if (pts[i].protocol == IPPROTO_ICMP) {
	    pkt = prepare_icmp(&pts[i], dip, buf+40, 100);
	    if (send_pkt(ssockfd, pkt, (buf+40-pkt)+100) < 0)
		printf("send error\n");
	} else {
	    printf("protocol %d not implemented.\n", pts[i].protocol);
	}
    }
}
