#ifndef _CTRLD_H_
#define _CTRLD_H_
#include <sys/types.h>
#include <netinet/in.h>
#include "popid.h"

extern int listen_control_channel(u_int16_t);
extern int accept_conn(int listenfd, struct sockaddr_in *);
extern int send_control_rsp(int, char *);
extern int handle_ctrlcmd(probe_t *probe, char *);

#endif


