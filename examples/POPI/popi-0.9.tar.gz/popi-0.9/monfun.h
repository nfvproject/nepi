#ifndef _MONFUN_H_
#define _MONFUN_H_

int open_monsock(u_int32_t, u_int16_t);
void close_monsock(void);
void send_monmsg(const char *fmt,...);

#endif
