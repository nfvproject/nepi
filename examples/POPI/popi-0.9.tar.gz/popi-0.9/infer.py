#!/usr/bin/env python
#
#
# $Header: /data/cvsroot/plportest/anadata/Attic/infer.py,v 1.1.2.1 2007/11/26 08:46:29 lgh Exp $

import sys
import getopt
from rlranklib import calc_rlrank, part_sort, kpart_rec

def usage():
    print "usage : infer.py [options] filename"
    print "        -a       alpha(default=0.99)"

def calc_anrs(k, bursts, verbose=0):
    """calculate ANRS for each packet type"""

    nrs = [-1] * k
    nb  = len(bursts)
    st  = 0
    for burst in bursts:
        lrs = [[i, burst[i]] for i in range(0, len(burst))]
        rrs = calc_rlrank(lrs, 0)
        st += sum([(rr[1]*k - (k+1)/2.0)**2 for rr in rrs])
        if verbose:
            print "RR", " ".join([ "%d/%.3f" % (rr[0],rr[1]) for rr in rrs ])
        for rr in rrs:
            assert rr[1] >= 0
            if nrs[rr[0]] < 0:
                nrs[rr[0]] = rr[1]
            else:
                nrs[rr[0]] += rr[1]
    j = 0
    anrs = []
    anrimap = {}
    for i in range(0, k):
        if nrs[i] > 0:
            anrs.append(nrs[i]/nb)
            anrimap[j] = i
            j += 1
    return (anrs, anrimap, st)

def cluster_pktypes(anrs, anrimap, nb, npt, alpha=0.999, verbose=0):
    """Group Paritition based on ANR using recursive k-means"""
    part = kpart_rec(anrs, nb, alpha, len(anrs), verbose=verbose)
    part = part_sort(anrs, part)
    anrs_ = [-1] * npt
    part_ = [-1] * npt
    for i in range(0, len(anrs)):
        anrs_[anrimap[i]] = anrs[i]
        part_[anrimap[i]] = part[i]
    return (anrs_, part_)

def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "a:")
    except:
        usage()
        sys.exit(1)

    alpha       = 0.999
    nr          = 0
    opt_verbose = 0
    for o, a in opts:
        if o == '-a':
            alpha = float(a)

    bursts = []
    for line in open(args[0]):
        line = line.rstrip()
        fds = line.split(" ")
        if fds[0] == "args":
            for arg in fds[1:]:
                (k, v) = arg.split("=")
                if k == "nr":
                    nr = int(v)
        if fds[0] == "pktypes":
            pktypes = fds[1:]
        elif fds[0] == "popid":
            bursts.append([int(x) for x in fds[2:]])

    npt = len(bursts[0])
    nb = len(bursts)
    (anrs, anrimap, st) = calc_anrs(npt, bursts)
    (anrs, part) = cluster_pktypes(anrs, anrimap, nb, npt, alpha=alpha)

    print "nr=%d nb=%d " % (nr, nb)
    print "%-15s %-6s %-5s %-5s" % ("pktype", "#group", "#ANR", "#nrcvd")
    for i in range(0, npt):
        print "%-15s %-6d %-5.3f %-5d" % (pktypes[i], part[i], anrs[i],
                                          sum([x[i] for x in bursts]))

if __name__ == '__main__':
    main()
