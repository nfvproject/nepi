.. include:: replace.txt

Mesh NetDevice
--------------

*Placeholder chapter*

The Mesh NetDevice based on 802.11s was added in *ns-3.6*. An overview
presentation by Kirill Andreev was published at the wns-3 workshop
in 2009: `<http://www.nsnam.org/wiki/Wns3-2009>`_.
