#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <stdarg.h>

#include "errfun.h"
#include "monfun.h"

#define NMON_SERVERS 1

extern char local_ip_str[];
extern char program_name[];

static int mon_sockfd = -1;
static struct sockaddr_in mon_servaddr[NMON_SERVERS];

/* if cannot open monsock, the prog is terminated */
int
open_monsock(u_int32_t ip, u_int16_t port)
{
    if ((mon_sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
	err_ret("open mon_socket");
	return -1;
    } else {
	bzero(mon_servaddr, NMON_SERVERS*sizeof(struct sockaddr_in));
	mon_servaddr[0].sin_family = AF_INET;
	mon_servaddr[0].sin_port   = htons(port);
	mon_servaddr[0].sin_addr.s_addr = ip;
    }
    return 0;
}

void
close_monsock()
{
    close(mon_sockfd);
}

void
send_monmsg(const char *fmt,...)
{
    char buf[400], *tstr;
    time_t curtime;
    struct tm *ptm;
    int i, n;
    va_list ap;

    if (mon_sockfd == -1)
	return;

    sprintf(buf, "%s %s ", local_ip_str, program_name);
    n = strlen(buf);
    
    va_start(ap, fmt);    
    vsnprintf(buf + n, sizeof(buf) - n - 1, fmt, ap);
    va_end(ap);

    for (i = 0; i < NMON_SERVERS; ++i) {
	if (sendto(mon_sockfd, buf, strlen(buf), 0, (struct sockaddr *)&mon_servaddr[i], sizeof(struct sockaddr_in)) < 0) {
	    err_ret("sendto mon_sockfd");
	}
    }
}
