/*
 * popid specific 
 */

#ifndef _POPID_H_
#define _POPID_H_

#include <pcap.h>

#include "popi_common.h"
#include "utils.h"

#define CHECK_INTVL 10
#define MAX_RAWPKTS 40
#define PKTDMPLEN   70

typedef struct {
    u_int8_t used;
    u_int8_t ipkt;
    u_int16_t iround;
} __attribute__ ((packed)) rcvpkt_t;

typedef struct {
    u_int32_t saddr;           /* network order */
    u_int16_t magic;           /* network order */
    char pl_peer;              /* is peer a planetlab host? */
    char dumpfnpfx[255];       /* dump filename prefix */
    int ctrlfd, dumpfd, logfd;
    int dump_eintr;            /* number of EINTR when dumping a packet */
    int nr, nb, nrpts, intvl;  /* intvl:(us), nrpt: number of pkt types */
    char statfeed;
    char tcpemulate;           /* use tcp emulate mode */
    cbuf_t cbuf;
    u_int32_t last_tvsec;      /* tvsec of most recently rcvd packet */
    u_int16_t ipkt, iburst_earliest;
    int rpkt_ttl;
    struct {
	u_int8_t protocol;
	u_int16_t sport_id;    /* network order */
	u_int16_t dport_type;  /* network order */
	u_int32_t th_seq;      /* th_seq received for SYN packet (host order) */
    } rpts[MAX_RAWPKTS];       /* received packet types */
    int nrtcp;                 /* # of TCP pkt types handshaked */
    u_int32_t th_seq;          /* tcpseq for SYN/ACK and RST. (host order) */
    rcvpkt_t *rcvpkts;         /* store received pkts */
    int rcvpkts_head, rcvpkts_tail;
    int rcvpkts_total, rcvpkts_missed;
} probe_t;

extern u_int32_t lastcheck_tv_sec;
extern u_int32_t last_showalive;

void get_pcap_stats(struct pcap_stat *ps);
void send_statfeed(probe_t *probe);
int is_planetlab_popid();


#endif
