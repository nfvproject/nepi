#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
/* write() */
#include <unistd.h>

#include "common.h"
#include "errfun.h"
#include "ctrl.h"

extern int opt_verbose;

int
open_control_channel(u_int32_t daddr, u_int16_t dport, u_int8_t ttl)
{
    int fd;
    struct sockaddr_in sin;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	err_ret("[%s]: socket failed", __func__);
	return -1;
    }
    if (setsockopt(fd, SOL_IP, IP_TTL, &ttl, 1) < 0) {
	err_ret("[%s]: setsockopt failed", __func__);
	return -1;
    }
    bzero(&sin, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = daddr;
    sin.sin_port = htons(dport);
    if (connect(fd, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
	err_ret("[%s]: connect failed", __func__);
	return -1;
    }
    return fd;
}

int
send_control_cmd(int fd, char *cmd)
{
    static char eof[] = "\n";
    struct iovec cmdv[2];
    
    cmdv[0].iov_base = cmd;
    cmdv[0].iov_len  = strlen(cmd);
    cmdv[1].iov_base = eof;
    cmdv[1].iov_len  = 1;

#if ((DEBUG) & (DEBUG_C))
    dbg_msg("[%s] cmd:%s\n", __func__, cmd);
#endif
    if (writev(fd, cmdv, 2) < 0) {
	err_ret("[%s]:", __func__);
	return -1;
    }
    return 0;
}
