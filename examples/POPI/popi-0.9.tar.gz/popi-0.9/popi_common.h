#ifndef _POPI_COMMON_H_
#define _POPI_COMMON_H_
/* 
 * common structure, variable shared by popi and popid.
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h> 

#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <fcntl.h>

#include <errno.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdarg.h>
#include <ctype.h>
#include <assert.h>

/*
 * +--------+-----------+----------+--...--+
 * | IP(20) | L4 HEADER | POPIHDR  |  PAD  |
 * +--------+-----------+----------+--...--+
 */
#define POPIHDRLEN   30
#define PD_VERSION   4
typedef struct {
    u_int8_t  hlen;                  /* data len */
    u_int16_t round;                 /* round */
    u_int8_t  ipkt;
#if BYTE_ORDER == LITTLE_ENDIAN
    unsigned char reserve:4,
	          ver:4;
#elif BYTE_ORDER == BIG_ENDIAN
    unsigned char ver:4,
	          reserve:4;
#endif
    u_int8_t  type;                  /* type, reserved for future use */
    u_int16_t magic;                 /* magic number */
    u_int16_t check;                 /* checksum for datamx struct */
    u_int32_t  tv_sec;
    u_int32_t  tv_usec;
    u_int32_t  echo_sec;
    u_int32_t  echo_usec;
    u_int32_t  ck0;                   /* source ip, source port, dest port */
} __attribute__ ((packed)) datamx_t;

extern char rev[];
extern char program_name[];
extern char local_ip_str[];
extern u_int32_t local_ip;
extern u_int32_t local_netmask;
#define CTRLPORT    8964
#define REV_LEN     20
#define MAX_STATFEED_LEN 1460
#endif
