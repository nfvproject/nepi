/*
 * popi client specific
 */

#ifndef _POPI_H_

#include"popi_common.h"

#define MAX_RAWPKTS 40

typedef struct {
    u_int8_t ipkt;
    u_int8_t ipt;
    u_int16_t ir;
    u_int8_t ttl;
    u_int8_t sent;
} __attribute__ ((packed)) sndpkt_t;

typedef struct {
    u_int32_t daddr;                            /* destination address, network order */
    u_int16_t magic;                            /* host order */
    char pl_peer;                               /* is peer a planetlab host? */
    int ctrlchannel;                            /* open control channel? */
    char sdump;                                 /* dump at receive? */
    char statfeed;                              /* need statfeed? */
    char tcpemulate;                            /* tcp emulation mode */
    int dumpfd, ctrlfd;                         /* dump, ctrl channel fd */
    FILE *ofp;
    char dumpfname[255], ofname[255];           /* packet dump / result filename */
    char pmode;                                 /* 0: end-to-end mode, 1: hop-by-hop mode */
    int nr, nb, intvl;                          /* 3 parameters from mode 0 */
    u_int8_t start_ttl, end_ttl;                /* probe start ttl, end_ttl */
    u_int8_t spkt_ttl;                          /* ttl in TCP packets sent in control channel */
    char waitinusec;
    struct itimerval usec_intvl;

    /* global var for all probe packets */
    int pktlen;                                 /* packet len (include IP hdr) */
    u_int32_t syn_seq;                          /* for all TCP firewall punching packets */
    u_int32_t ack_seq;                          /* for all TCP SYN probe packets */
    u_int16_t icmpseq;                          /* for all ICMP probe packets */
    u_int8_t ttl;                               /* for all probe packets */
    u_int16_t ipid;                             /* for all probe packets */    
    u_int16_t iround, iburst;                   /* ith round,burst in the one probe */
    int nsendpts;
    pktype_t sendpts[MAX_RAWPKTS];
    char tcp_establish[MAX_RAWPKTS];            /* hole punched in firewall */
    cbuf_t cbuf;                                /* buffer to receive control feedback */
    int **sndpkts, *sndpkts_;                   /* 2-D array to store the history of sent packets */
    sndpkt_t spkts[65536];                      /* send packets indexed by ipid */
    int nrh;                                    /* # of round for history recording */
    int **nrcvd, *nrcvd_;                       /* # of pkts rcvd by popid (burst by burst) */
    int **nicmperr, *nicmperr_;                 /* # of icmp error pkts replied from each hop */
    int *nrcvd_total;                           /* # of pkts rcvd by popid (total) */
    int nrcvd_seq[MAX_RAWPKTS];                 /* nrcvd for each burst position */
    int ooostat[MAX_RAWPKTS][MAX_RAWPKTS];      /* ooostat[i][j] for 'i' sent earlier than 'j', but arrived later */
    int nooo;                                   /* number bursts having ooo events. */
} cprobe_t;

extern int opt_verbose;

#endif
