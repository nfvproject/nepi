#ifndef _ERRFUN_H_
#define _ERRFUN_H_
#include<stdarg.h>
#include<stdio.h>

void err_ret(const char *,...);
void err_sys(const char *,...);
void err_msg(const char *,...);
void dbg_msg(const char *,...);
void err_quit(const char *,...);
int open_logfile(const char *);

extern int daemonized;

#endif
